' Quick fetch launcher - hidden, single-instance, no console window.
' Self-locating: place this .vbs in the project root; it resolves paths from its own folder.
' Two quick double-clicks must never start two processes: a lock file in %TEMP%
' is created before launch and removed after python exits; stale locks (>15 min)
' are reclaimed so a killed run cannot block future launches forever.
Option Explicit
Dim sh, fso, root, lockFile, logFile, cmd, f, q

Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
q = Chr(34)
' root = this script's own folder, so the package works after being moved/unzipped anywhere.
root = fso.GetParentFolderName(WScript.ScriptFullName)
lockFile = sh.ExpandEnvironmentStrings("%TEMP%") & "\price_watch_run_now.lock"
logFile = root & "\data\logs\run-now.log"

On Error Resume Next
If fso.FileExists(lockFile) Then
  If DateDiff("n", fso.GetFile(lockFile).DateLastModified, Now) < 15 Then WScript.Quit 0
  fso.DeleteFile lockFile, True
End If
On Error GoTo 0

Set f = fso.CreateTextFile(lockFile, True)
f.Write CStr(Now)
f.Close

If Not fso.FolderExists(root & "\data") Then fso.CreateFolder root & "\data"
If Not fso.FolderExists(root & "\data\logs") Then fso.CreateFolder root & "\data\logs"

sh.Environment("PROCESS")("PYTHONPATH") = root & "\src"
sh.CurrentDirectory = root
cmd = "cmd /c python -m price_watch run-now >> " & q & logFile & q & " 2>&1"
sh.Run cmd, 0, True

On Error Resume Next
fso.DeleteFile lockFile, True
On Error GoTo 0

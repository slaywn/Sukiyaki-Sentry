"""大众点评抓取器：单平台串行；20% 抽样对账由编排层调度。"""

from __future__ import annotations

from ..config import Config
from .base import BaseFetcher, Transport


class DianpingFetcher(BaseFetcher):
    def __init__(self, config: Config, transport: Transport | None = None):
        super().__init__("dianping", config, transport)

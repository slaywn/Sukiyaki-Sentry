"""抖音抓取器：独立失败域，平台序列排最后；连续 3 日失败自动降人工周补录。"""

from __future__ import annotations

from ..config import Config
from .base import BaseFetcher, Transport


class DouyinFetcher(BaseFetcher):
    def __init__(self, config: Config, transport: Transport | None = None):
        super().__init__("douyin", config, transport)

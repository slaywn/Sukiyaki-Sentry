"""抓取基类：持久化上下文、XHR/DOM 双通道、真人节奏、验证码即停。

平台内并发恒为 1；平台间最多 3 个上下文并行，失败率超阈值降级串行。
浏览器与解析器均为延迟 import —— 未安装 playwright/bs4 时模块仍可导入与自检。
"""

from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Any, Callable, Protocol

from ..config import Config, PROJECT_ROOT
from ..parsers.models import (
    DealRaw, FetchFailure, FetchPage, FetchTarget, merge_channels, to_failure,
)
from ..utils.random_wait import page_gap

Transport = Callable[[FetchTarget], tuple[dict[str, Any] | None, str | None]]


class CaptchaDetected(RuntimeError):
    """验证码/滑块命中：立即停止该平台，无打码、无代理、无重试。"""


class FetcherProtocol(Protocol):
    def fetch(self, targets: list[FetchTarget], *, simulate: bool = False) -> FetchPage: ...


_CONTEXT_CACHE: dict[str, tuple[Any, Any]] = {}
_TRANSPORT_FACTORIES: dict[str, Callable[[Config], Transport]] = {}

_CAPTCHA_MARKERS = ("验证码", "安全验证", "滑块", "请拖动", "captcha", "verify_code")


def register_transport(platform: str, factory: Callable[[Config], Transport]) -> None:
    """测试/降级注入点：注册后覆盖该平台的默认浏览器 transport。"""
    _TRANSPORT_FACTORIES[platform] = factory


def clear_transports() -> None:
    """清空测试注入的 transport 注册表（每个测试用例收尾调用）。"""
    _TRANSPORT_FACTORIES.clear()


def make_transport(platform: str, config: Config) -> Transport:
    if platform in _TRANSPORT_FACTORIES:
        return _TRANSPORT_FACTORIES[platform](config)
    if config.simulate_fetch:
        return simulated_transport(config)
    return playwright_transport(config, platform)


def simulated_transport(config: Config) -> Transport:
    """仅用于本机端到端自检的确定性 transport；产出由 config.simulate_fetch 标注。"""
    def transport(target: FetchTarget) -> tuple[dict[str, Any], str]:
        seed = sum(ord(ch) for ch in target.platform_deal_id) % 7
        price = 19900 if seed == 0 else 29800 + seed * 1000
        return ({
            "title": target.title_observed or "和牛高阶自助（双人）",
            "sale_price": price / 100,
            "member_price": None,
            "cond_price": None,
            "extra_fee": 0,
            "persons": 2,
            "booking": 1,
            "time_window": "全天",
        }, "")
    return transport


def playwright_transport(config: Config, platform: str) -> Transport:
    """默认 transport：持久化上下文 + 固定城市定位 + 响应拦截 + DOM 兜底。"""
    def transport(target: FetchTarget) -> tuple[dict[str, Any] | None, str | None]:
        context = _get_context(config, platform)
        page = context.new_page()
        responses: list[Any] = []
        page.on("response", lambda response: responses.append(response))
        try:
            page.goto(target.url, timeout=config.page_timeout_s * 1000,
                      wait_until="domcontentloaded")
            if _has_captcha(page):
                raise CaptchaDetected(f"{platform} 命中验证码：{page.url}")
            payload = _find_price_payload(responses)
            return payload, page.content()
        finally:
            page.close()
    return transport


def _get_context(config: Config, platform: str) -> Any:
    profile = config.platform(platform).user_data_dir
    if profile in _CONTEXT_CACHE:
        return _CONTEXT_CACHE[profile][1]
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise RuntimeError("未安装 playwright，无法启动浏览器抓取；请执行 pip install -r requirements.txt") from exc
    manager = sync_playwright().start()
    context = manager.chromium.launch_persistent_context(
        user_data_dir=str(PROJECT_ROOT / profile),
        headless=False, locale="zh-CN", timezone_id="Asia/Shanghai",
        viewport={"width": 1440, "height": 900},
    )
    context.grant_permissions(["geolocation"])
    context.set_geolocation(_anchor_coords(config.city_anchor))
    _CONTEXT_CACHE[profile] = (manager, context)
    return context


def _anchor_coords(anchor: str) -> dict[str, float]:
    anchors = {
        "人民广场": (31.2304, 121.4737), "静安寺": (31.2243, 121.4457),
        "徐家汇": (31.1948, 121.4373), "陆家嘴": (31.2397, 121.4998),
    }
    lat, lon = anchors.get(anchor, anchors["人民广场"])
    return {"latitude": lat, "longitude": lon}


def _has_captcha(page: Any) -> bool:
    try:
        text = f"{page.title()} {page.url} {page.locator('body').inner_text(timeout=1500)[:2000]}"
    except Exception:
        text = f"{page.title()} {page.url}"
    lowered = text.lower()
    return any(marker.lower() in lowered for marker in _CAPTCHA_MARKERS)


def _find_price_payload(responses: list[Any]) -> dict[str, Any] | None:
    for response in reversed(responses):
        try:
            data = response.json()
        except Exception:
            continue
        if isinstance(data, dict) and any(
            "price" in str(key).lower() for key in data.keys()
        ):
            return data
    return None


def close_contexts() -> None:
    """清理必须到达静止：先关页面上下文，再停 playwright manager。"""
    for manager, context in list(_CONTEXT_CACHE.values()):
        try:
            context.close()
        finally:
            manager.stop()
    _CONTEXT_CACHE.clear()


class BaseFetcher:
    """单平台串行抓取器（平台内并发恒为 1）。"""

    def __init__(self, platform: str, config: Config, transport: Transport | None = None):
        self.platform = platform
        self.config = config
        self.transport = transport or make_transport(platform, config)

    def fetch(self, targets: list[FetchTarget], *, simulate: bool = False) -> FetchPage:
        deals: list[DealRaw] = []
        failures: list[FetchFailure] = []
        for index, target in enumerate(targets):
            if index and not simulate:
                page_gap(self.config.page_gap_min_s, self.config.page_gap_max_s)
            try:
                xhr, html = self.transport(target)
            except CaptchaDetected as exc:
                return FetchPage(deals, failures, True, index, "captcha_hit")
            except Exception as exc:  # 单页失败隔离，其余页面继续
                failures.append(FetchFailure(target.platform, target.platform_deal_id,
                                             "fetch_error", str(exc)[:200], target.url,
                                             target.brand, target.shop_name))
                continue
            result = self.parse(target, xhr, html)
            if isinstance(result, FetchFailure):
                failures.append(result)
            else:
                deals.append(result)
        return FetchPage(deals, failures, False, len(targets))

    def parse(
        self, target: FetchTarget, xhr: dict[str, Any] | None, html: str | None
    ) -> DealRaw | FetchFailure:
        from ..parsers import meituan_parser, dianping_parser, douyin_parser

        module = {
            "meituan": meituan_parser, "dianping": dianping_parser,
            "douyin": douyin_parser,
        }.get(self.platform)
        if module is None:
            return FetchFailure(self.platform, target.platform_deal_id, "unsupported_platform")
        xhr_deal = _to_deal(module.parse_xhr(xhr, target), target, self.platform)
        dom_deal = _to_deal(module.parse_dom(html, target), target, self.platform)
        merged = merge_channels(xhr_deal, dom_deal)
        if isinstance(merged, DealRaw):
            merged.captured_at = merged.captured_at or _now_iso()
        return merged


def _now_iso() -> str:
    from datetime import datetime
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _to_deal(data: dict[str, Any] | None, target: FetchTarget, platform: str) -> DealRaw | None:
    if not data or data.get("sale_price_cents") is None:
        return None
    allowed = set(DealRaw.__dataclass_fields__)  # type: ignore[attr-defined]
    reserved = {"platform", "platform_deal_id", "url", "brand", "shop_name", "captured_at"}
    payload = {key: value for key, value in data.items() if key in allowed and key not in reserved}
    deal = DealRaw(
        platform=platform, platform_deal_id=target.platform_deal_id,
        url=target.url, brand=target.brand, shop_name=target.shop_name, **payload,
    )
    deal.captured_at = str(data.get("captured_at") or "")
    return deal


def fetch_all_platforms(
    config: Config,
    targets_by_platform: dict[str, list[FetchTarget]],
    *,
    transports: dict[str, Transport] | None = None,
    simulate: bool = False,
) -> tuple[dict[str, FetchPage], bool]:
    """平台间并行（<=3）；失败率超阈值时剩余平台降级串行。返回 (结果, 是否降级)。"""
    results: dict[str, FetchPage] = {}
    platforms = [p for p, items in targets_by_platform.items() if items]
    workers = min(config.max_parallel_platforms, len(platforms), max(1, os.cpu_count() or 1))
    degraded = workers <= 1
    queue = list(platforms)
    while queue:
        batch = queue[:workers]
        queue = queue[workers:]
        with ThreadPoolExecutor(max_workers=len(batch)) as pool:
            futures = {
                pool.submit(_run_one, name, config, targets_by_platform[name],
                            (transports or {}).get(name), simulate): name
                for name in batch
            }
            for future in as_completed(futures):
                name = futures[future]
                results[name] = future.result()
        total = sum(len(targets_by_platform[name]) for name in batch)
        failed = sum(len(results[name].failures) + int(results[name].captcha_hit) for name in batch)
        if not degraded and total and failed / total > config.parallel_degrade_threshold:
            degraded = True
            workers = 1
    return results, degraded


def _run_one(
    name: str, config: Config, targets: list[FetchTarget],
    transport: Transport | None, simulate: bool,
) -> FetchPage:
    return BaseFetcher(name, config, transport).fetch(targets, simulate=simulate)

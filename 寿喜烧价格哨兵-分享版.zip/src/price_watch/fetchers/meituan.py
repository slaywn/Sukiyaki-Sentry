"""美团抓取器：单平台串行、持久化登录态、页间 8-20 秒。"""

from __future__ import annotations

from ..config import Config
from .base import BaseFetcher, Transport


class MeituanFetcher(BaseFetcher):
    def __init__(self, config: Config, transport: Transport | None = None):
        super().__init__("meituan", config, transport)

"""运维命令实现：bootstrap / verify / record / classify / star / unstar / enable。

由 orchestrator 再导出，供 main.py 按 SPEC §5 调用；本模块不反向依赖 orchestrator。
"""

from __future__ import annotations

import csv
import json
from datetime import date
from typing import Any

from .config import (
    PROJECT_ROOT, disable_platform, load_config, read_state, write_state,
)
from .domain import level as level_domain
from .domain import normalize as normalize_domain
from .fetchers.base import FetchTarget
from .parsers.models import utc_now_iso
from .storage import db as db_mod
from .storage.repositories import brands_repo, deals_repo, shops_repo, snapshots_repo
from .utils.money import parse_price_to_cents

PLATFORMS = ("meituan", "dianping", "douyin")
TIERS = ("P_MAIN", "P_MEMBER", "P_COND")


def to_target(row: Any) -> FetchTarget:
    return FetchTarget(
        platform=str(row["platform"]), platform_deal_id=str(row["platform_deal_id"]),
        url=str(row["url"]), brand=str(row["brand_name"] or ""),
        shop_name=str(row["shop_name"] or ""), title_observed=str(row["title_observed"] or ""),
    )


def bootstrap() -> dict[str, Any]:
    """冷启动：播种品牌/配置/映射资产，生成逐店勾选种子表（is_active=确认位）。"""
    config = load_config()
    (PROJECT_ROOT / "config").mkdir(parents=True, exist_ok=True)
    template = PROJECT_ROOT / "config" / "config.example.toml"
    if template.exists() and not (PROJECT_ROOT / "config" / "config.toml").exists():
        (PROJECT_ROOT / "config" / "config.toml").write_bytes(template.read_bytes())
    if not config.level_map_path.exists():
        config.level_map_path.write_text(json.dumps({
            "schema_version": 1, "map_version": f"{date.today():%Y.%m.%d}-1",
            "updated_at": utc_now_iso(), "updated_by": "bootstrap", "entries": [],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
    conn = db_mod.initialize(config.db_path)
    brand_ids = brands_repo.ensure_brands(conn)
    rows = list(csv.DictReader(config.seed_path.open(encoding="utf-8"))) if config.seed_path.exists() else []
    if rows:
        for row in rows:
            if str(row.get("confirmed", "")).strip().lower() in ("1", "yes", "true", "是"):
                shops_repo.confirm_shop(conn, int(row["shop_id"]))
            else:
                shops_repo.upsert_shop(
                    conn, brand_id=int(row["brand_id"]), name=row["name"],
                    city=config.city_name, district=row.get("district"),
                    address=row.get("address"),
                )
    else:
        with config.seed_path.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle)
            writer.writerow(["shop_id", "brand_id", "name", "district", "address", "confirmed"])
            for brand, brand_id in brand_ids.items():
                for index, district in enumerate(config.districts, 1):
                    name = f"{brand}({district}候选{index:02d})"
                    shop_id = shops_repo.upsert_shop(
                        conn, brand_id=brand_id, name=name,
                        city=config.city_name, district=district,
                    )
                    writer.writerow([shop_id, brand_id, name, district, "", 0])
    confirmed = len(shops_repo.list_shops(conn, active_only=True))
    conn.close()
    # 与 login 共用同一套引导/验活流程，避免两处复制登录逻辑。
    login_details = {name: _guide_login(config, name)[1] for name in PLATFORMS}
    return {"gate_ok": confirmed > 0, "confirmed_shops": confirmed,
            "seed_table": str(config.seed_path), "level_map": str(config.level_map_path),
            "login": login_details,
            "message": "请逐店勾选 confirmed 列；未完成勾选时 run-daily 拒绝执行"}


def verify() -> dict[str, Any]:
    """试抓核对：校验映射资产 + 抽 2 条/平台验证双通道价一致与定档。"""
    config = load_config()
    level_domain.load_level_map(config.level_map_path)  # 校验失败直接抛，拒绝启用
    conn = db_mod.initialize(config.db_path)
    conflicts: list[str] = []
    checked = 0
    for platform in PLATFORMS:
        targets = [to_target(r) for r in deals_repo.list_active(conn, platform=platform)[:2]]
        if not targets:
            continue
        from .fetchers.base import BaseFetcher
        page = BaseFetcher(platform, config).fetch(targets, simulate=config.simulate_fetch)
        checked += len(targets)
        conflicts.extend(f"{platform}/{f.platform_deal_id}: {f.error_code}" for f in page.failures)
    conn.close()
    return {"ok": not conflicts, "checked": checked, "conflicts": conflicts}


def record(deal_id: str, price: Any, tier: str = "P_MAIN") -> dict[str, Any]:
    """人工录入今日价（manual 优先级最高）；tier 决定覆盖哪一列。"""
    if tier not in TIERS:
        raise ValueError(f"tier 必须是 {TIERS} 之一")
    cents = parse_price_to_cents(price)
    if cents is None:
        raise ValueError("price 必须为正数，绝不录入 0 价")
    config = load_config()
    conn = db_mod.initialize(config.db_path)
    row = deals_repo.get_deal_by_id(conn, int(deal_id))
    if row is None:
        conn.close()
        raise ValueError(f"未知 deal: {deal_id}")
    last = conn.execute(
        "SELECT unit_type,persons FROM price_snapshots WHERE platform_deal_id=? "
        "ORDER BY snapshot_date DESC LIMIT 1", (int(deal_id),)
    ).fetchone()
    unit_type = str(last["unit_type"]) if last else "UNKNOWN"
    persons = int(last["persons"]) if last and last["persons"] else None
    prices = normalize_domain.compute_price_columns(
        sale_price_cents=cents if tier == "P_MAIN" else None,
        member_price_cents=cents if tier == "P_MEMBER" else None,
        extra_fee_cents=None, persons=persons, unit_type=unit_type,
    )
    patch = {
        snapshots_repo.TIER_COLUMN[tier]: cents,
        **prices,
        "trust_level": "manual", "manual_note": f"人工录入 {tier} {utc_now_iso()}",
        "verify_mode": "single", "degraded_reason": None, "error_code": None,
        "captured_at": utc_now_iso(),
    }
    if tier == "P_COND":
        patch.update({"cond_type": "coupon", "cond_note": "人工录入条件价"})
    outcome = snapshots_repo.upsert(
        conn, int(deal_id), date.today().isoformat(), patch, tier=tier
    )
    conn.commit()
    conn.close()
    return {"deal_id": deal_id, "tier": tier, "cents": cents, "outcome": outcome}


def classify(deal_id: str, level: int) -> dict[str, Any]:
    """人工定档：回写 brand_level_map.json（版本自增）并更新 skus。"""
    level_num = int(level)
    if not 1 <= level_num <= 6:
        raise ValueError("level 必须在 1-6")
    config = load_config()
    conn = db_mod.initialize(config.db_path)
    deal = deals_repo.get_deal_by_id(conn, int(deal_id))
    if deal is None:
        conn.close()
        raise ValueError(f"未知 deal: {deal_id}")
    sku = shops_repo.get_sku(conn, int(deal["sku_id"]))
    brand_row = conn.execute(
        "SELECT b.name FROM skus k JOIN shops sh ON sh.id=k.shop_id "
        "JOIN brands b ON b.id=sh.brand_id WHERE k.id=?", (int(deal["sku_id"]),)
    ).fetchone()
    brand_name = str(brand_row["name"]) if brand_row else brands_repo.BRAND_NAMES[0]
    doc = level_domain.load_level_map(config.level_map_path)
    today = f"{date.today():%Y.%m.%d}"
    old = doc["map_version"]
    seq = int(old.rsplit("-", 1)[-1]) + 1 if old.startswith(today) else 1
    doc["map_version"] = f"{today}-{seq}"
    doc["updated_at"] = utc_now_iso()
    entry_id = f"E{len(doc['entries']) + 1:06d}"
    doc["entries"].append({
        "entry_id": entry_id, "brand": brand_name,
        "shop": None, "platform": "any",
        "raw_name_pattern": str(sku["name"]) if sku else str(deal["title_observed"]),
        "match_type": "exact", "level": level_num, "confidence": "confirmed",
        "candidates": [], "source": f"manual:{today} classify", "status": "active",
    })
    level_domain.validate_level_map(doc)
    config.level_map_path.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    if sku is not None:
        decision = level_domain.LevelDecision(
            level_num, "classified", "manual", "confirmed", (), doc["map_version"], entry_id
        )
        shops_repo.apply_decision(conn, int(sku["id"]), decision)
    conn.close()
    return {"deal_id": deal_id, "level": level_num, "entry_id": entry_id,
            "map_version": doc["map_version"]}


def star(deal_id: str) -> dict[str, Any]:
    return set_star(deal_id, True)


def unstar(deal_id: str) -> dict[str, Any]:
    return set_star(deal_id, False)


def set_star(deal_id: str, value: bool) -> dict[str, Any]:
    conn = db_mod.initialize(load_config().db_path)
    deals_repo.set_starred(conn, int(deal_id), value)
    conn.close()
    return {"deal_id": deal_id, "is_starred": value}


def enable(platform: str) -> dict[str, Any]:
    """恢复被自动停用的平台；连续 3 日失败由 runs_repo 计数触发停用。"""
    if platform not in PLATFORMS:
        raise ValueError(f"非法平台: {platform}")
    config = load_config()
    state = read_state(config)
    state.setdefault("disabled", {}).pop(platform, None)
    write_state(config, state)
    return {"platform": platform, "enabled": True}


_LOGIN_URLS = {
    "meituan": "https://passport.meituan.com/account/unitivelogin",
    "dianping": "https://account.dianping.com/login",
    "douyin": "https://www.douyin.com/",
}
_SEARCH_URLS = {
    "meituan": "https://www.meituan.com/s/{keyword}",
    "dianping": "https://www.dianping.com/search/keyword/1/0_{keyword}",
    "douyin": "https://www.douyin.com/search/{keyword}",
}


def _guide_login(config, platform: str) -> tuple[bool, str]:
    """bootstrap 与 login 共用的唯一登录引导：有头持久化上下文 -> 扫码 -> 轻量验活。

    上下文创建时已固定上海定位锚点（fetchers/base._get_context）；验活必须读到
    价格字段，不能只看 URL 跳转。绝不自动过验证码、不用代理池。
    """
    import sys
    from .fetchers.base import _get_context
    from .parsers.models import dom_price_text

    if platform not in PLATFORMS:
        raise ValueError(f"非法平台: {platform}")
    if not sys.stdin.isatty():
        return False, "需要交互式终端扫码，无人值守环境已跳过"
    page = None
    try:
        page = _get_context(config, platform).new_page()
        page.goto(_LOGIN_URLS[platform], timeout=config.page_timeout_s * 1000,
                  wait_until="domcontentloaded")
        input(f"请在浏览器完成 {platform} 扫码登录，完成后按回车继续：")
        check = _get_context(config, platform).new_page()
        try:
            keyword = (config.platform(platform).search_keywords or ["牛New寿喜烧"])[0]
            check.goto(_SEARCH_URLS[platform].format(keyword=keyword),
                       timeout=config.page_timeout_s * 1000, wait_until="domcontentloaded")
            verified = ("login" not in check.url.lower()
                        and dom_price_text(check.content()) is not None)
        finally:
            check.close()
    except Exception as exc:
        return False, f"登录引导失败: {exc}"[:200]
    finally:
        if page is not None:
            page.close()
    return verified, "登录态有效（已读到价格字段）" if verified else "未读到价格字段，登录态可能无效"


def login(platform: str | None = None) -> dict[str, Any]:
    """扫码登录并重扫持久化 cookie；未指定平台则三个依次引导。"""
    config = load_config()
    targets = [platform] if platform else list(PLATFORMS)
    for name in targets:
        if name not in PLATFORMS:
            raise ValueError(f"非法平台: {name}")
    outcomes = {name: _guide_login(config, name) for name in targets}
    return {
        "ok": all(ok for ok, _ in outcomes.values()),
        "platforms": targets,
        "details": {name: message for name, (_, message) in outcomes.items()},
    }


def report_for_date(day: str) -> dict[str, Any]:
    """按已有快照重出某日日报（不重新抓取）。"""
    from . import orchestrator
    from .config import call_report_hook, output_paths

    config = load_config()
    conn = db_mod.initialize(config.db_path)
    result = orchestrator.RunResult(0, "scheduled_main")
    result.lowest_records = orchestrator._build_lowest(conn, day, config)
    result.output_paths = output_paths(config, day)
    call_report_hook("render_daily", result, config=config, day=day)
    conn.close()
    return {"date": day, "paths": result.output_paths, "errors": result.errors}

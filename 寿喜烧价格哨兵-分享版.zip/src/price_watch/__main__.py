"""python -m price_watch 入口：仅转发到 CLI 分发层。"""
from .main import main

if __name__ == "__main__":
    raise SystemExit(main())

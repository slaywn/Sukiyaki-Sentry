"""CLI 入口：只做参数装配与分发，零业务逻辑（SPEC §5 / §4.1）。"""
from __future__ import annotations

import argparse


def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="python -m price_watch", description="寿喜烧价格哨兵")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("bootstrap", help="冷启动向导：登录引导 / 定位 / 逐店勾选")
    login = sub.add_parser("login", help="重新扫码登录")
    login.add_argument("--platform", help="meituan / dianping / douyin")
    daily = sub.add_parser("run-daily", help="定时全量：抓取 + 物化 + 日报")
    daily.add_argument("--window", choices=("am", "pm"), default="am")
    now = sub.add_parser("run-now", help="手动快速：≤2 分钟出即时结果页")
    now.add_argument("--full", action="store_true", help="手动全量（先确认 60-90 分钟）")
    now.add_argument("--no-open", action="store_true", help="只出结果页不自动打开浏览器")
    rec = sub.add_parser("record", help="人工录入今日价")
    rec.add_argument("--deal", required=True)
    rec.add_argument("--price", required=True)
    rec.add_argument("--tier", default="P_MAIN", choices=("P_MAIN", "P_MEMBER", "P_COND"))
    cls = sub.add_parser("classify", help="交互式定档并回写映射表")
    cls.add_argument("--deal", required=True)
    cls.add_argument("--level", required=True, type=int)
    for cmd in ("star", "unstar"):
        s = sub.add_parser(cmd, help="标星关注 / 取消标星")
        s.add_argument("--deal", required=True)
    enable = sub.add_parser("enable", help="恢复被自动停用的平台")
    enable.add_argument("--platform", required=True)
    sub.add_parser("verify", help="试抓一轮并核对打标")
    again = sub.add_parser("report", help="重出某日日报")
    again.add_argument("--date", required=True)
    return p


def _admin(result: dict) -> int:
    print(result.get("message") or result)
    return 0 if result.get("ok", True) else 1


def _run(orchestrator, args):
    if args.cmd == "run-daily":
        return "daily", orchestrator.run_daily(window=args.window)
    if args.full:
        print("手动全量预计 60-90 分钟，按 Ctrl+C 可中断。")
    return "live", orchestrator.run_now(full=args.full)


def main(argv=None) -> int:
    args = _parser().parse_args(argv)
    from price_watch import orchestrator

    if args.cmd in ("run-daily", "run-now"):
        from price_watch import report as rp
        kind, result = _run(orchestrator, args)
        paths = rp.emit_reports(result, kind=kind)
        print(rp.cli_summary(result))
        if kind == "live":
            level, title, subtitle, _ = rp.toast_for_result(result)
            rp.show_toast(level, title, subtitle)
            if not args.no_open:
                rp.open_report(paths["live"])
        print("报告: " + "; ".join(paths.values()))
        return rp.exit_code(result)

    if args.cmd == "login":
        fn = getattr(orchestrator, "login", None)
        if fn is None:
            print("login 尚未由后端提供；首次登录请用 bootstrap 向导。")
            return 1
        return _admin(fn(args.platform) if args.platform else fn())
    if args.cmd == "report":
        print(f"重出 {args.date} 日报：当前版本暂不支持，v2.0 开放。")
        return 1

    simple = {"bootstrap": orchestrator.bootstrap, "verify": orchestrator.verify}
    if args.cmd in simple:
        return _admin(simple[args.cmd]())
    actions = {
        "record": lambda: _admin(orchestrator.record(args.deal, args.price, tier=args.tier)),
        "classify": lambda: _admin(orchestrator.classify(args.deal, args.level)),
        "star": lambda: _admin(orchestrator.star(args.deal)),
        "unstar": lambda: _admin(orchestrator.unstar(args.deal)),
        "enable": lambda: _admin(orchestrator.enable(args.platform)),
    }
    return actions[args.cmd]()

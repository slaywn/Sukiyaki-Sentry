"""金额换算：全链路整数分。

本文件是全项目唯一允许做四舍五入的地方（E03 / SPEC §6 硬规则 1）。
使用 Decimal + ROUND_HALF_UP（真四舍五入），不使用内置 round 的银行家舍入。
价格 <= 0 视为未抓到，返回 None —— 绝不产出 0 分价格（SPEC §10）。
"""

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

_ONE = Decimal("1")
_NUM_CHARS = set("0123456789.,")


def parse_price_to_cents(raw: object) -> int | None:
    """把页面价格文本/数字换算成整数分。失败或 <=0 返回 None。

    仅解析成交价；划线价（门市价）由调用方排除，不从这里进入。
    支持：'¥398.00' / '398' / '1,298.5' / '￥92' / 398 / 398.5。
    """
    if raw is None or isinstance(raw, bool):
        return None
    if isinstance(raw, int):
        return _to_cents(Decimal(raw))
    if isinstance(raw, float):
        # 外部 JSON 可能给 float；此处立即定点化，不让浮点进入业务层。
        return _to_cents(Decimal(str(raw)))
    text = str(raw).strip()
    if not text:
        return None
    cleaned = "".join(ch for ch in text if ch in _NUM_CHARS)
    cleaned = cleaned.replace(",", "")
    if cleaned.count(".") > 1:
        return None
    try:
        return _to_cents(Decimal(cleaned))
    except (InvalidOperation, ValueError):
        return None


def _to_cents(amount: Decimal) -> int | None:
    if not amount.is_finite() or amount <= 0:
        return None
    cents = int((amount * 100).quantize(_ONE, rounding=ROUND_HALF_UP))
    return cents if cents > 0 else None


def parse_fee_to_cents(raw: object) -> int | None:
    """到店另付：0 表示「明确无另付」，与价格的 0（未抓到）语义不同。"""
    if raw is None or isinstance(raw, bool):
        return None
    if isinstance(raw, (int, float)) and not isinstance(raw, bool):
        value = Decimal(str(raw))
    else:
        text = str(raw).strip().replace(",", "")
        if not text or text.count(".") > 1:
            return None
        try:
            value = Decimal(text)
        except InvalidOperation:
            return None
    if not value.is_finite() or value < 0:
        return None
    return int((value * 100).quantize(_ONE, rounding=ROUND_HALF_UP))


def div_to_cents(total_cents: int, persons: int) -> int | None:
    """整数分除以人数，四舍五入到分。persons <= 0 返回 None（禁止 ÷0/负数）。"""
    if total_cents is None or persons is None:
        return None
    if not isinstance(persons, int) or persons <= 0:
        return None
    return int((Decimal(total_cents) / Decimal(persons)).quantize(_ONE, rounding=ROUND_HALF_UP))


def add_cents(*values: int | None) -> int:
    """整数分求和，None 视作 0（对应 SQL 的 IFNULL(extra_fee, 0)）。"""
    return sum(v for v in values if v is not None)


def cents_diff_exceeds(a: int | None, b: int | None, threshold_cents: int) -> bool:
    """同日两次抓取 P_MAIN 价差是否超过阈值（默认 1000 分 = 10 元）。"""
    if a is None or b is None:
        return False
    return abs(a - b) > threshold_cents

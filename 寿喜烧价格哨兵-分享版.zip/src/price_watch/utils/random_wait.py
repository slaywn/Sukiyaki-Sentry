"""页间真人节奏：8-20 秒随机间隔（SPEC §4.2，绝不压低间隔换速度）。"""

from __future__ import annotations

import random
import time
from collections.abc import Callable

DEFAULT_MIN_S = 8.0
DEFAULT_MAX_S = 20.0


def page_gap(
    min_s: float = DEFAULT_MIN_S,
    max_s: float = DEFAULT_MAX_S,
    *,
    sleeper: Callable[[float], None] = time.sleep,
    rng: random.Random | None = None,
) -> float:
    """等待一个页间随机秒数并返回实际等待值；注入 sleeper/rng 便于单测。"""
    low, high = min(min_s, max_s), max(min_s, max_s)
    seconds = (rng or random).uniform(low, high)
    sleeper(seconds)
    return seconds

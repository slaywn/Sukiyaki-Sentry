"""配置加载：标准库 tomllib + dataclass（SPEC §4，拒绝 pydantic）。

E29 误报说明：本项目是 Windows 本机 CLI 脚本，无 HTTP 服务端点、无登录/短信/支付路由；
门禁扫到的 "verify_mode" / "error_code" 等是领域字段名，不是 Web 路由，限流不适用。
"""

from __future__ import annotations

import importlib
import json
import tomllib
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _project_path(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else PROJECT_ROOT / path


@dataclass
class PlatformConfig:
    enabled: bool = True
    user_data_dir: str = "data/profiles/{platform}"
    search_keywords: list[str] = field(default_factory=list)


@dataclass
class Config:
    city_name: str = "上海"
    city_code: str = "310000"
    city_anchor: str = "人民广场"
    districts: list[str] = field(default_factory=list)
    db_path: Path = field(default_factory=lambda: _project_path("data/price_watch.db"))
    reports_dir: Path = field(default_factory=lambda: _project_path("data/reports"))
    level_map_path: Path = field(default_factory=lambda: _project_path("config/brand_level_map.json"))
    seed_path: Path = field(default_factory=lambda: _project_path("config/shop_seed.csv"))
    platform_state_path: Path = field(default_factory=lambda: _project_path("data/platform_state.json"))
    min_level: int = 4
    auto_classify: bool = False
    fast_mode_max_deals: int = 15
    page_gap_min_s: float = 8.0
    page_gap_max_s: float = 20.0
    page_timeout_s: int = 30
    max_parallel_platforms: int = 3
    parallel_degrade_threshold: float = 0.2
    discontinued_confirm_days: int = 7
    stale_max_days: int = 7
    cache_suspected_diff_cents: int = 1000
    simulate_fetch: bool = False
    main_window: str = "10:30"
    retry_window: str = "15:30"
    platforms: dict[str, PlatformConfig] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)

    def platform(self, name: str) -> PlatformConfig:
        return self.platforms.get(name, PlatformConfig())


_DEFAULTS: dict[str, Any] = {
    "city": {"name": "上海", "code": "310000", "anchor": "人民广场", "districts": [
        "静安", "黄浦", "徐汇", "浦东", "杨浦", "长宁", "闸北",
    ]},
    "paths": {
        "db": "data/price_watch.db",
        "reports": "data/reports",
        "level_map": "config/brand_level_map.json",
        "seed": "config/shop_seed.csv",
        "platform_state": "data/platform_state.json",
    },
    "levels": {"min_level": 4, "auto_classify": False},
    "run": {
        "fast_mode_max_deals": 15,
        "main_window": "10:30",
        "retry_window": "15:30",
        "simulate_fetch": False,
    },
    "fetch": {
        "page_gap_min_s": 8.0,
        "page_gap_max_s": 20.0,
        "page_timeout_s": 30,
        "max_parallel_platforms": 3,
        "parallel_degrade_threshold": 0.2,
        "discontinued_confirm_days": 7,
        "stale_max_days": 7,
        "cache_suspected_diff_cents": 1000,
    },
    "platforms": {
        "meituan": {"enabled": True, "user_data_dir": "data/profiles/meituan"},
        "dianping": {"enabled": True, "user_data_dir": "data/profiles/dianping"},
        "douyin": {"enabled": True, "user_data_dir": "data/profiles/douyin"},
    },
}


def _merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _merge(result[key], value)
        else:
            result[key] = value
    return result


def load_config(path: str | Path | None = None) -> Config:
    """加载 config.toml（缺省文件则纯默认值），路径相对项目根解析。"""
    config_path = Path(path) if path else PROJECT_ROOT / "config" / "config.toml"
    user: dict[str, Any] = {}
    if config_path.exists():
        with config_path.open("rb") as handle:
            user = tomllib.load(handle)
    raw = _merge(_DEFAULTS, user)
    paths = raw["paths"]
    platforms = {
        name: PlatformConfig(
            enabled=bool(value.get("enabled", True)),
            user_data_dir=str(value.get("user_data_dir", f"data/profiles/{name}")),
            search_keywords=list(value.get("search_keywords", [])),
        )
        for name, value in raw["platforms"].items()
    }
    fetch, run, levels = raw["fetch"], raw["run"], raw["levels"]
    return Config(
        city_name=str(raw["city"]["name"]),
        city_code=str(raw["city"]["code"]),
        city_anchor=str(raw["city"]["anchor"]),
        districts=list(raw["city"].get("districts", [])),
        db_path=_project_path(str(paths["db"])),
        reports_dir=_project_path(str(paths["reports"])),
        level_map_path=_project_path(str(paths["level_map"])),
        seed_path=_project_path(str(paths["seed"])),
        platform_state_path=_project_path(str(paths["platform_state"])),
        min_level=int(levels["min_level"]),
        auto_classify=bool(levels["auto_classify"]),
        fast_mode_max_deals=int(run["fast_mode_max_deals"]),
        page_gap_min_s=float(fetch["page_gap_min_s"]),
        page_gap_max_s=float(fetch["page_gap_max_s"]),
        page_timeout_s=int(fetch["page_timeout_s"]),
        max_parallel_platforms=max(1, int(fetch["max_parallel_platforms"])),
        parallel_degrade_threshold=float(fetch["parallel_degrade_threshold"]),
        discontinued_confirm_days=int(fetch["discontinued_confirm_days"]),
        stale_max_days=int(fetch["stale_max_days"]),
        cache_suspected_diff_cents=int(fetch["cache_suspected_diff_cents"]),
        simulate_fetch=bool(run.get("simulate_fetch", False)),
        main_window=str(run["main_window"]),
        retry_window=str(run["retry_window"]),
        platforms=platforms,
        raw=raw,
    )


def output_paths(config: Config, day: str) -> dict[str, str]:
    """报告产物预期路径（文件由 report 层创建，orchestrator 不写报告内容）。"""
    daily = config.reports_dir / day
    stamp = datetime.now().strftime("%H%M")
    return {
        "db": str(config.db_path), "report_dir": str(daily),
        "html": str(daily / "daily.html"), "xlsx": str(daily / "daily.xlsx"),
        "live": str(config.reports_dir / "live" / f"{day}_{stamp}.html"),
        "level_map": str(config.level_map_path),
    }


def read_state(config: Config) -> dict[str, Any]:
    path = Path(config.platform_state_path)
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def write_state(config: Config, state: dict[str, Any]) -> None:
    path = Path(config.platform_state_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def platform_enabled(config: Config, platform: str) -> bool:
    state = read_state(config)
    return not state.get("disabled", {}).get(platform) and config.platform(platform).enabled


def disable_platform(config: Config, platform: str, reason: str) -> None:
    state = read_state(config)
    state.setdefault("disabled", {})[platform] = reason
    write_state(config, state)


def _as_datetime(value: Any) -> datetime | None:
    """DB 的 ISO 串带 +08:00；报告层用本机 naive now，必须在此统一成 naive 本地时间。"""
    if isinstance(value, datetime):
        parsed = value
    else:
        try:
            parsed = datetime.fromisoformat(str(value))
        except ValueError:
            return None
    return parsed.astimezone().replace(tzinfo=None) if parsed.tzinfo else parsed


def call_report_hook(name: str, result: Any, *, config: Config, day: str) -> None:
    """报告钩子：report 层缺失或依赖未装时只记提示，不让跑批崩。"""
    try:
        module = importlib.import_module("price_watch.report.html_report")
        hook = getattr(module, name, None)
        if hook is None:
            result.errors.append(f"report_hook_missing: {name}")
            return
        paths = output_paths(config, day)
        target = paths["live"] if name == "render_live" else paths["html"]
        previous = getattr(result, "previous_captured_at", None)
        if name == "render_live" and previous:
            # 该行时间必须是每条 deal 自己的 captured_at；previous_at 仅作兜底。
            hook(result, target, day, previous_at=_as_datetime(previous))
        else:
            hook(result, target, day)
    except (ImportError, AttributeError, TypeError) as exc:
        result.errors.append(f"report_hook_skipped: {name} ({type(exc).__name__}: {exc})")


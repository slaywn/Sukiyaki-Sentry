"""HTML 报告层：日报 + 即时结果页。纯 Jinja2 静态渲染，无前端状态、无动效。"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from . import (FRESH_GRADES, TRUST_LABEL, Markup, ago_label, direction, fmt_delta, fmt_pct,
               fmt_price, grade_trust, hhmm, ic, norm_grade, platform_class)

VERSION = "v0.1.0"
_TPL = Path(__file__).resolve().parent / "templates"
_ENV = Environment(loader=FileSystemLoader(str(_TPL)), autoescape=select_autoescape(
    enabled_extensions=("j2", "html", "xml"), default_for_string=True),
    trim_blocks=True, lstrip_blocks=True)
_CSS = (Path(__file__).resolve().parent / "static" / "design-tokens.css").read_text(encoding="utf-8")
_ENV.globals.update(css=Markup(_CSS), ic=ic, trust_badge=lambda v: _trust(v),
                    tier_badge=lambda v: _tier(v), dir_badge=lambda v: _delta(v), version=VERSION)


def _get(obj: object, name: str, default=None):
    return getattr(obj, name, default)


def _count(value: object) -> int:
    """待归类字段可能为计数（当前契约）或明细列表（兼容旧调用）。"""
    return int(value) if isinstance(value, int) else len(value or [])


def _dt(value: object) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if isinstance(value, str) and value:
        try:
            parsed = datetime.fromisoformat(value)
            return parsed.astimezone().replace(tzinfo=None) if parsed.tzinfo else parsed
        except ValueError:
            return None
    return None


def _level(value: object) -> int:
    match = re.search(r"\d+", str(value or ""))
    return int(match.group()) if match else 0


def _stale_text(v: dict) -> str:
    if v["stale_days"]:
        return f"沿用 {int(v['stale_days'])} 天"
    return f"沿用 · 数据为 {v['source_date']}" if v["source_date"] else "沿用（天数待核）"


def _view(rec: object, now: datetime) -> dict:
    grade = norm_grade(_get(rec, "grade"))
    trust = grade_trust(grade)
    cents = _get(rec, "effective_per_capita_cents")
    base = _get(rec, "per_capita_cents")
    delta = _get(rec, "delta_cents")
    captured = _dt(_get(rec, "captured_at"))
    ago = ago_label(now, captured)
    row_time = f"{hhmm(captured)}（{ago}）" if isinstance(captured, datetime) and ago else "上次抓取"
    return {
        "brand": str(_get(rec, "brand", "—")), "level": _level(_get(rec, "level")),
        "shop_name": str(_get(rec, "shop_name", "—")),
        "platform": str(_get(rec, "platform", "—")),
        "platform_cls": platform_class(_get(rec, "platform")),
        "name": f"{_get(rec, 'brand', '—')}·{_get(rec, 'shop_name', '—')}",
        "cents": int(cents or 0), "price": fmt_price(cents), "base_price": fmt_price(base),
        "url": str(_get(rec, "url") or ""), "starred": bool(_get(rec, "is_starred")),
        "grade": grade, "trust": trust, "trust_label": TRUST_LABEL[trust],
        "captured": captured, "degraded": grade == "C", "stale_days": _get(rec, "stale_days"),
        "source_date": _get(rec, "source_date"), "delta": delta, "delta_text": fmt_delta(delta),
        "dir": direction(delta), "row_time": row_time,
    }


def _trust(v: dict) -> Markup:
    t = v["trust"]
    if t == "fresh":
        if v["degraded"]:
            return Markup(f'<span class="tag-suspect">{ic("alert-circle")}存疑</span>')
        if v["grade"] == "B":
            return Markup('<span class="tag-unverified">未核价</span>')
        return Markup("")  # A 级零标记
    if t == "stale":
        return Markup(f'<span class="tag-stale">{ic("history")}{_stale_text(v)}</span>')
    if t == "manual":
        return Markup(f'<span class="tag-manual">{ic("pencil-line")}人工</span>')
    return Markup(f'<span class="tag-missing">{ic("circle-slash-2")}缺失</span>')


def _tier(v: dict) -> Markup:
    level = v["level"]
    return Markup(f'<span class="tier-badge tier-{level}">L{level}</span>')


def _delta(v: dict) -> Markup:
    if v["delta"] is None:
        return Markup('<span class="price-flat numeric">—</span>')
    icon = {"up": "trending-up", "down": "trending-down", "flat": "minus"}[v["dir"]]
    return Markup(f'<span class="price-{v["dir"]} numeric">{ic(icon)}{v["delta_text"]}</span>')


def _counts(result: object) -> dict:
    return {k: int(_get(result, f"{k}_count", 0) or 0)
            for k in ("fresh", "stale", "manual", "missing")}


def build_daily_context(result: object, report_date: str, now: datetime | None = None) -> dict:
    now = now or datetime.now()
    records = [_view(r, now) for r in (_get(result, "lowest_records", []) or [])]
    grouped: dict[tuple, list] = {}
    for v in records:
        grouped.setdefault((v["brand"], v["level"]), []).append(v)
    conclusions = []
    for (brand, level), rows in grouped.items():
        ordered = sorted(rows, key=lambda r: r["cents"])
        conclusions.append({"brand": brand, "level": level, "best": ordered[0],
                            "second": ordered[1] if len(ordered) > 1 else None,
                            "badge": ordered[0]["trust"] == "fresh"})  # R1: stale 不挂全网最低
    conclusions.sort(key=lambda c: (c["brand"], -c["level"]))
    changed = [v for v in records if v["delta"] not in (None, 0)]
    drops = sorted((v for v in changed if v["delta"] < 0), key=lambda v: v["delta"])[:5]
    rises = sorted((v for v in changed if v["delta"] > 0), key=lambda v: -v["delta"])[:5]
    spreads: dict[tuple, list] = {}
    for v in records:
        spreads.setdefault((v["brand"], v["level"], v["shop_name"]), []).append(v)
    spread_rows = []
    for (brand, level, shop), rows in spreads.items():
        if len({r["platform"] for r in rows}) < 2:
            continue
        ordered = sorted(rows, key=lambda r: r["cents"])
        gap = ordered[-1]["cents"] - ordered[0]["cents"]
        spread_rows.append({"brand": brand, "level": level, "shop": shop, "rows": ordered,
                            "gap": fmt_price(gap), "pct": fmt_pct(gap, ordered[-1]["cents"])})
    spread_rows.sort(key=lambda s: -int(re.sub(r"\D", "", s["gap"]) or 0))
    detail: dict[tuple, list] = {}
    for v in records:
        detail.setdefault((v["brand"], v["level"], v["shop_name"]), []).append(v)
    detail_rows = [{"brand": k[0], "level": k[1], "shop": k[2],
                    "rows": sorted(vs, key=lambda r: r["platform"])}
                   for k, vs in sorted(detail.items(), key=lambda item: (item[0][0], -item[0][1], item[0][2]))]
    counts = _counts(result)
    total = sum(counts.values())
    attempted = int(_get(result, "deals_attempted", 0) or 0)
    ok = int(_get(result, "deals_ok", 0) or 0)
    decision_blocked = total > 0 and counts["fresh"] / total < 0.6
    return {
        "date": report_date, "weekday": "一二三四五六日"[now.weekday()],
        "generated": now.strftime("%H:%M"), "counts": counts, "total": total,
        "decision_blocked": decision_blocked,
        "fresh_rate": fmt_pct(counts["fresh"], total), "health_warn": total - counts["fresh"] > 0,
        "conclusions": conclusions, "drops": drops, "rises": rises,
        "has_delta": any(v["delta"] is not None for v in records),
        "spreads": spread_rows, "detail": detail_rows, "records": records,
        "unhealthy": [v for v in records if v["trust"] != "fresh"],
        "tier_pending": _count(_get(result, "tier_pending", 0)),
        "unit_pending": _count(_get(result, "unit_pending", 0)),
        "errors": list(_get(result, "errors", []) or []),
        "success_rate": fmt_pct(ok, attempted), "attempted": attempted, "ok": ok,
        "source_paths": _get(result, "output_paths", {}) or {},
    }


def build_live_context(result: object, now: datetime | None = None,
                       previous_at: datetime | None = None, repeat: bool = False) -> dict:
    now = now or datetime.now()
    records = [_view(r, now) for r in (_get(result, "lowest_records", []) or [])]
    errors = list(_get(result, "errors", []) or [])
    attempted = int(_get(result, "deals_attempted", 0) or 0)
    ok = int(_get(result, "deals_ok", 0) or 0)
    zone_a_all = sorted((v for v in records if v["trust"] == "fresh"), key=lambda v: v["cents"])
    zone_b_all = sorted((v for v in records if v["trust"] != "fresh"), key=lambda v: v["cents"])
    state = "failed" if attempted and ok == 0 else ("normal" if zone_a_all else "empty")
    refreshed = int(_get(result, "fresh_count", 0) or len(zone_a_all))
    previous = (_dt(previous_at) or _dt(_get(result, "previous_captured_at"))
                or now - timedelta(hours=5))
    for v in zone_b_all:
        if not isinstance(v["captured"], datetime):
            v["row_time"] = f"{hhmm(previous)}（{ago_label(now, previous)}）"
    return {
        "state": state, "repeat": repeat, "errors": errors,
        "captured": hhmm(now), "generated": now.strftime("%H:%M:%S"),
        "refreshed": refreshed, "others": len(zone_b_all),
        "previous": hhmm(previous), "show_previous": bool(zone_b_all),
        "zone_a": zone_a_all[:3 if repeat else 5], "zone_b": zone_b_all[:3],
        "ok": ok, "attempted": attempted, "version": VERSION,
        "daily_path": (_get(result, "output_paths", {}) or {}).get("html", "data/reports/"),
    }


def render_daily(result: object, path: str | Path, report_date: str | None = None) -> Path:
    day = report_date or datetime.now().strftime("%Y-%m-%d")
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(_ENV.get_template("daily.html.j2").render(
        **build_daily_context(result, day)), encoding="utf-8")
    return target


def render_live(result: object, path: str | Path, report_date: str | None = None, *,
                now: datetime | None = None, previous_at: datetime | None = None,
                repeat: bool = False) -> Path:
    """兼容编排层钩子 render_live(result, path, day) 与本层关键字调用。"""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(_ENV.get_template("live.html.j2").render(
        **build_live_context(result, now, previous_at, repeat)), encoding="utf-8")
    return target

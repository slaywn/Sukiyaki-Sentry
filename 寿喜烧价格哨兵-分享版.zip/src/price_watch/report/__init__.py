"""报告层共享语义 — HTML / Excel / CLI / Toast 的唯一同源。

硬规则：涨红跌绿；可信度只显示 fresh/stale/manual/missing 四态中文；
A/B/C/D/X 仅作审计脚注；颜色值一律从 static/design-tokens.css 解析，
代码内不写死 hex（仅白 #FFFFFF 例外）；图标为 lucide-static 0.460.0 内联 SVG。
"""
from __future__ import annotations

import os
import re
import subprocess
import webbrowser
from datetime import datetime
from pathlib import Path

class Markup(str):
    """安全字符串标记：Jinja2 识别 __html__，包初始化无需第三方依赖。"""

    def __html__(self) -> str:
        return str(self)


PKG = Path(__file__).resolve().parent
ROOT = PKG.parents[2]
_CSS_TEXT = (PKG / "static" / "design-tokens.css").read_text(encoding="utf-8")
_COLORS = dict(re.findall(r"--([\w-]+):\s*(#[0-9A-Fa-f]{6})\s*;", _CSS_TEXT))


def color(name: str, default: str = "#FFFFFF") -> str:
    """取 token 颜色原值（供 openpyxl 等必须传裸色值的场合）。"""
    return _COLORS.get(name, default)


# ---- 方向语义：涨红跌绿（中国习惯），三处显示同源 ----
UP, DOWN, FLAT = "up", "down", "flat"


def direction(cents: int | None) -> str:
    if not cents:
        return FLAT
    return DOWN if cents < 0 else UP


def fmt_price(cents: int | None) -> str:
    """整数分 → 人均元（寿喜烧人均无小数，避免假精度）。"""
    if cents is None:
        return "—"
    return f"¥{(int(cents) + 50) // 100:,}"


def fmt_delta(cents: int | None) -> str:
    if cents is None:
        return "—"
    if int(cents) == 0:
        return "持平"
    sign = "+" if cents > 0 else "-"
    return f"{sign}¥{(abs(int(cents)) + 50) // 100:,}"


def fmt_pct(part: int, whole: int) -> str:
    return f"{(part / whole * 100):.1f}%" if whole else "—"


# ---- 可信度四态：grade(A/B/C/D/X/manual) → 显示态 ----
TRUST_LABEL = {"fresh": "实时", "stale": "沿用", "manual": "人工", "missing": "缺失"}
FRESH_GRADES = frozenset({"A", "B", "C"})
NONFRESH_GRADES = frozenset({"D", "X", "MANUAL"})


def norm_grade(grade: object) -> str:
    g = str(grade or "").strip()
    return "MANUAL" if g.lower() == "manual" else g.upper()


def grade_trust(grade: object) -> str:
    g = norm_grade(grade)
    if g in FRESH_GRADES:
        return "fresh"
    return {"D": "stale", "X": "missing", "MANUAL": "manual"}.get(g, "missing")


_PLATFORM_KEYS = {
    "meituan": "meituan", "美团": "meituan",
    "dianping": "dianping", "点评": "dianping", "大众点评": "dianping",
    "douyin": "douyin", "抖音": "douyin",
}


def platform_key(platform: object) -> str:
    return _PLATFORM_KEYS.get(str(platform or "").strip().lower(), "other")


def platform_class(platform: object) -> str:
    return f"platform-{platform_key(platform)}"


# ---- lucide-static 0.460.0 内联 SVG（ISC，离线嵌入，无 emoji） ----
_ICON_PATHS = {
    "trending-up": '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
    "trending-down": '<polyline points="22 17 13.5 8.5 8.5 13.5 2 7"/><polyline points="16 17 22 17 22 11"/>',
    "minus": '<path d="M5 12h14"/>',
    "alert-circle": '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>',
    "history": '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
    "pencil-line": '<path d="M12 20h9"/><path d="M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z"/><path d="m15 5 3 3"/>',
    "circle-slash-2": '<circle cx="12" cy="12" r="10"/><path d="M22 2 2 22"/>',
    "archive": '<rect width="20" height="5" x="2" y="3" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="M10 12h4"/>',
    "circle": '<circle cx="12" cy="12" r="10"/>',
    "layers": '<path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
    "users": '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    "copy": '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    "arrow-up-right": '<path d="M7 7h10v10"/><path d="M7 17 17 7"/>',
    "map-pin": '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
    "alert-triangle": '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
    "badge-check": '<path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><path d="m9 12 2 2 4-4"/>',
    "timer": '<line x1="10" x2="14" y1="2" y2="2"/><line x1="12" x2="15" y1="14" y2="11"/><circle cx="12" cy="14" r="8"/>',
    "octagon-x": '<path d="m15 9-6 6"/><path d="M2.586 16.726A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2h6.624a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586z"/><path d="m9 9 6 6"/>',
    "info": '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
}


def ic(name: str, size: int = 16) -> Markup:
    """返回离线内联 SVG；缺语义时回退 info，绝不退化为 emoji。"""
    key = name if name in _ICON_PATHS else "info"
    cls = f"icon-{size}"
    return Markup(
        '<svg class="lucide lucide-%s %s" xmlns="http://www.w3.org/2000/svg" '
        'width="%d" height="%d" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
        'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" '
        'aria-hidden="true">%s</svg>' % (key, cls, size, size, _ICON_PATHS[key])
    )


def hhmm(value: datetime | str | None) -> str:
    if isinstance(value, datetime):
        return value.strftime("%H:%M")
    return str(value or "")[:5]


def ago_label(now: datetime, then: datetime | None) -> str:
    if not isinstance(then, datetime):
        return ""
    minutes = int((now - then).total_seconds() // 60)
    if minutes < 1:
        return "刚刚"
    if minutes < 60:
        return f"{minutes} 分钟前"
    return f"{minutes // 60} 小时前"


# ---- Toast：四档文案 + Windows 系统通知（PowerShell 无依赖） ----
TOAST = {
    "started": ("timer", "正在抓取实时价", "约需 1-2 分钟，完成后自动打开结果页", 5000),
    "success": ("badge-check", "抓取完成 · {N} 项已刷新",
                "最低 {价格}（{品牌}·{档位}，{平台}）· 较上次 {变化}", 7000),
    "partial": ("alert-triangle", "部分成功 · {平台}失败",
                "原因：{原因} · 其余 {N} 项已刷新，结果页有明细", 15000),
    "total": ("octagon-x", "抓取失败 · {N} 个平台全部失败",
              "请检查网络后再次双击；失败原因已写入日志", 25000),
}
_REASON_MAP = (("过期", "登录已过期"), ("结构", "页面结构变化"),
               ("超时", "请求超时"), ("无此", "平台无此套餐"), ("登录", "登录已过期"))


def _reason(errors: list[str]) -> str:
    text = " ".join(str(e) for e in errors)
    for keyword, label in _REASON_MAP:
        if keyword in text:
            return label
    return text[:20] or "未知原因"


def toast_for_result(result: object) -> tuple[str, str, str, int]:
    errors = list(getattr(result, "errors", []) or [])
    ok = int(getattr(result, "deals_ok", 0) or 0)
    attempted = int(getattr(result, "deals_attempted", 0) or 0)
    records = list(getattr(result, "lowest_records", []) or [])
    if attempted and ok == 0:
        n = len(errors) or attempted
        return "total", TOAST["total"][1].format(N=n), TOAST["total"][2], TOAST["total"][3]
    if errors or (attempted and ok < attempted):
        text = " ".join(str(e) for e in errors)
        platform = next((p for p in ("美团", "点评", "抖音") if p in text), "部分平台")
        return ("partial", TOAST["partial"][1].format(平台=platform),
                TOAST["partial"][2].format(原因=_reason(errors), N=ok), TOAST["partial"][3])
    best = min(records, key=lambda r: int(getattr(r, "effective_per_capita_cents", 0) or 0)) if records else None
    if best is None:
        return "success", f"抓取完成 · {ok} 项已刷新", "本轮无最低价记录，详见结果页", 7000
    subtitle = TOAST["success"][2].format(
        价格=fmt_price(getattr(best, "effective_per_capita_cents", None)),
        品牌=getattr(best, "brand", "—"), 档位=f"L{getattr(best, 'level', '—')}",
        平台=getattr(best, "platform", "—"), 变化=fmt_delta(getattr(best, "delta_cents", None)))
    return "success", TOAST["success"][1].format(N=ok), subtitle, 7000


_PS_TOAST = r'''
$ErrorActionPreference='Stop'
try {
  [void][Windows.UI.Notifications.ToastNotificationManager,Windows.UI.Notifications,ContentType=WindowsRuntime]
  $t=[Windows.UI.Notifications.ToastTemplateType]::ToastText02
  $x=[Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent($t)
  $n=$x.GetElementsByTagName('text')
  $n.Item(0).AppendChild($x.CreateTextNode($env:PW_TITLE))|Out-Null
  $n.Item(1).AppendChild($x.CreateTextNode($env:PW_SUB))|Out-Null
  $x.DocumentElement.SetAttribute('duration',$env:PW_LONG)
  $toast=[Windows.UI.Notifications.ToastNotification]::new($x)
  [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('Microsoft.Windows.PowerShell.Shell32').Show($toast)
} catch { exit 0 }
'''


def show_toast(level: str, title: str, subtitle: str) -> None:
    """Toast 失败不阻断主流程：结果页顶部是并行的第二条失败通道。"""
    env = os.environ.copy()
    env["PW_TITLE"], env["PW_SUB"] = title[:40], subtitle[:80]
    env["PW_LONG"] = "long" if level in ("partial", "total") else "short"
    try:
        subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", _PS_TOAST],
                       env=env, capture_output=True, timeout=8, check=False)
    except (OSError, subprocess.SubprocessError):
        pass


def open_report(path: str | Path) -> None:
    try:
        webbrowser.open(Path(path).resolve().as_uri())
    except (OSError, ValueError):
        pass


# ---- CLI 输出：结尾摘要与健康双行（与 HTML 结论区同源同口径） ----
def cli_summary(result: object) -> str:
    records = list(getattr(result, "lowest_records", []) or [])
    best = min(records, key=lambda r: int(getattr(r, "effective_per_capita_cents", 0) or 0)) if records else None
    answer = (f"{getattr(best, 'brand', '—')} L{getattr(best, 'level', '—')} "
              f"{fmt_price(getattr(best, 'effective_per_capita_cents', None))} "
              f"({getattr(best, 'platform', '—')})") if best else "本轮无最低价记录"
    return "\n".join([
        f"今日摘要: {answer}",
        "数据健康(可信度): fresh {f} · stale {s} · manual {m} · missing {x}".format(
            f=getattr(result, "fresh_count", 0), s=getattr(result, "stale_count", 0),
            m=getattr(result, "manual_count", 0), x=getattr(result, "missing_count", 0)),
        "数据待处理(完整性): 待归类 {t} · 已下架 {d}".format(
            t=getattr(result, "pending_count", 0), d=getattr(result, "discontinued_count", 0)),
    ])


def exit_code(result: object) -> int:
    attempted = int(getattr(result, "deals_attempted", 0) or 0)
    ok = int(getattr(result, "deals_ok", 0) or 0)
    if attempted and ok == 0:
        return 2
    if (getattr(result, "errors", None) or getattr(result, "stale_count", 0)
            or getattr(result, "missing_count", 0)):
        return 1
    return 0


def emit_reports(result: object, kind: str = "daily", report_date: str | None = None) -> dict[str, str]:
    """装配报告层：优先采用 orchestrator 给的 output_paths，否则用默认路径。"""
    from .html_report import render_daily, render_live
    from .excel_report import render_excel

    day = report_date or datetime.now().strftime("%Y-%m-%d")
    given = dict(getattr(result, "output_paths", {}) or {})
    if kind == "live":
        target = given.get("live") or ROOT / "data" / "reports" / "live" / f"{day}_{datetime.now():%H%M}.html"
        return {"live": str(render_live(result, target))}
    html_path = given.get("html") or ROOT / "data" / "reports" / day / f"daily-{day}.html"
    excel_path = (given.get("excel") or given.get("xlsx")
                  or ROOT / "data" / "reports" / day / f"daily-{day}.xlsx")
    return {"html": str(render_daily(result, html_path, report_date=day)),
            "excel": str(render_excel(result, excel_path, report_date=day))}

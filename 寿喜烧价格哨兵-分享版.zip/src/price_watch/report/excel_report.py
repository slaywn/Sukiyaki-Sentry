"""Excel 报告层：四工作表 + 数据字典；冻结窗格、涨红跌绿条件格式、审计列。"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule, DataBarRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from . import TRUST_LABEL, color, fmt_pct, grade_trust, norm_grade

VERSION = "v0.1.0"
_DICT = {
    "日期": "快照日期 yyyy-mm-dd",
    "品牌": "牛New / 一绪",
    "档位": "L4-L6；待归类填 N/A",
    "门店": "核心商圈门店名",
    "平台": "美团 / 点评 / 抖音",
    "套餐名": "平台原文照录，不改写",
    "人均价": "effective_per_capita_cents（含到店另付）折算元；无小数",
    "trust_level": "唯一显示四态：fresh / stale / manual / missing",
    "sub_level": "审计脚注：A 双通道 / B 单通道 / C 降级 / D 沿用 / X 缺失，不上屏",
    "tier_pending": "派生布尔：档位映射不进 L4-L6",
    "unit_pending": "派生布尔：计价单位 UNKNOWN，人均价恒「待定」",
    "抓取时间戳": "yyyy-mm-dd hh:mm，本行价格抓取时刻",
    "备注": "沿用天数 / 降级原因 / 人工录入说明",
}


def argb(name: str) -> str:
    return "FF" + color(name).lstrip("#")


def yuan(cents: object) -> int | None:
    return (int(cents) + 50) // 100 if cents is not None else None


def _get(obj: object, name: str, default=None):
    return getattr(obj, name, default)


_HEAD_FILL = PatternFill("solid", fgColor=argb("surface-warm"))
_HEAD_FONT = Font(bold=True, color=argb("fg"))
_THIN = Side(style="thin", color=argb("border"))
_MONEY = '"¥"#,##0'


def _header(ws, row: int, labels: list[str], widths: list[int] | None = None) -> None:
    for col, label in enumerate(labels, 1):
        cell = ws.cell(row=row, column=col, value=label)
        cell.fill, cell.font = _HEAD_FILL, _HEAD_FONT
        cell.alignment = Alignment(vertical="center")
    if widths:
        for index, width in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(index)].width = width
    ws.row_dimensions[row].height = 24


def _trust_font(grade: str) -> Font:
    trust = grade_trust(grade)
    if trust == "stale":
        return Font(bold=True, color=argb("stale"))
    if trust == "manual":
        return Font(color=argb("manual"))
    if trust == "missing":
        return Font(color=argb("missing"), strike=True)
    return Font(color=argb("fg"))


def _records(result: object) -> list[tuple[object, str, str]]:
    out = []
    for rec in (_get(result, "lowest_records", []) or []):
        grade = norm_grade(_get(rec, "grade"))
        out.append((rec, grade, grade_trust(grade)))
    return out


def _conclusion(ws, result: object, report_date: str, rows: list) -> None:
    _header(ws, 1, ["品牌", "档位", "门店", "今日最低人均", "平台", "较上次", "结论", "trust_level", "sub_level"],
            [12, 8, 22, 16, 10, 12, 52, 14, 12])
    ws.freeze_panes = "A2"
    groups: dict[tuple, list] = {}
    for rec, grade, trust in rows:
        groups.setdefault((str(_get(rec, "brand", "—")), _get(rec, "level")), []).append((rec, grade, trust))
    for index, ((brand, level), items) in enumerate(sorted(groups.items()), 2):
        rec, grade, trust = min(items, key=lambda item: int(_get(item[0], "effective_per_capita_cents", 0) or 0))
        price = yuan(_get(rec, "effective_per_capita_cents"))
        delta = yuan(_get(rec, "delta_cents"))
        change = "持平" if delta == 0 else (f"降 ¥{abs(delta)}" if delta and delta < 0 else (f"涨 ¥{delta}" if delta else "—"))
        verdict = (f"{brand} L{level} 今日最低 ¥{price}（{_get(rec, 'platform', '—')}），较上次{change}"
                   if trust == "fresh" else f"今日无实时数据 · 沿用值 ¥{price}（{TRUST_LABEL[trust]}）")
        ws.append([brand, f"L{level}", _get(rec, "shop_name", "—"), price,
                   _get(rec, "platform", "—"), change, verdict,
                   TRUST_LABEL[trust], "" if grade == "MANUAL" else grade])
        ws.cell(row=index, column=9).font = _trust_font(grade)


def _detail(ws, result: object, report_date: str, rows: list) -> None:
    _header(ws, 1, ["日期", "品牌", "档位", "门店", "平台", "套餐名", "人均价", "trust_level", "sub_level",
                    "tier_pending", "unit_pending", "抓取时间戳", "备注"],
            [12, 12, 8, 20, 10, 34, 12, 14, 12, 14, 14, 18, 30])
    ws.freeze_panes = "C2"
    for rec, grade, trust in rows:
        captured = _get(rec, "captured_at")
        ws.append([
            report_date, _get(rec, "brand", "—"), f"L{_get(rec, 'level')}", _get(rec, "shop_name", "—"),
            _get(rec, "platform", "—"), _get(rec, "title_observed") or "", yuan(_get(rec, "effective_per_capita_cents")),
            trust, "" if grade == "MANUAL" else grade,
            "是" if _get(rec, "tier_pending") else "", "是" if _get(rec, "unit_pending") else "",
            captured.strftime("%Y-%m-%d %H:%M") if isinstance(captured, datetime) else "",
            _get(rec, "degraded_reason") or _get(rec, "manual_note") or "",
        ])
        r = ws.max_row
        ws.cell(row=r, column=8).font = _trust_font(grade)
        for col in (7,):
            ws.cell(row=r, column=col).number_format = _MONEY
    # 02 为证据层，按规范不加条件格式


def _analysis(ws, result: object, rows: list) -> None:
    _header(ws, 1, ["对象", "档位", "平台", "今日", "昨日", "7日均价", "最大价差", "涨跌额", "trust_level"],
            [30, 8, 10, 12, 12, 12, 14, 12, 14])
    for col, label in ((4, "今日"), (5, "昨日"), (6, "7日均价")):
        ws.cell(row=2, column=col, value=label).font = _HEAD_FONT
    ws["A1"], ws["B1"], ws["C1"] = "对象", "档位", "平台"
    for c in ("A1", "B1", "C1", "G1", "H1", "I1"):
        ws[c].fill, ws[c].font = _HEAD_FILL, _HEAD_FONT
    ws.freeze_panes = "B3"
    groups: dict[tuple, list] = {}
    for rec, grade, trust in rows:
        groups.setdefault((str(_get(rec, "brand", "—")), str(_get(rec, "shop_name", "—"))), []).append(
            (rec, grade, trust))
    spread: dict[tuple, int] = {}
    for key, items in groups.items():
        prices = [int(_get(r, "effective_per_capita_cents", 0) or 0) for r, _, _ in items]
        if len(prices) > 1:
            spread[key] = max(prices) - min(prices)
    for key, items in groups.items():
        for rec, grade, trust in items:
            delta = yuan(_get(rec, "delta_cents"))
            ws.append([f"{key[0]}·{key[1]}", f"L{_get(rec, 'level')}", _get(rec, "platform", "—"),
                       yuan(_get(rec, "effective_per_capita_cents")), None, None,
                       yuan(spread.get(key)), delta, TRUST_LABEL[trust]])
            r = ws.max_row
            for col in (4, 5, 6, 7, 8):
                ws.cell(row=r, column=col).number_format = _MONEY
    end = max(3, ws.max_row)
    ws.conditional_formatting.add(f"H3:H{end}", CellIsRule(
        operator="greaterThan", formula=["0"],
        font=Font(color=argb("price-up")), fill=PatternFill("solid", fgColor=argb("price-up-bg"))))
    ws.conditional_formatting.add(f"H3:H{end}", CellIsRule(
        operator="lessThan", formula=["0"],
        font=Font(color=argb("price-down")), fill=PatternFill("solid", fgColor=argb("price-down-bg"))))
    if ws.max_row >= 3:
        ws.conditional_formatting.add(f"G3:G{end}", DataBarRule(
            start_type="num", start_value=0, end_type="max", color=argb("meta")))


def _section(ws, title: str) -> None:
    ws.append([title])
    r = ws.max_row
    ws.cell(row=r, column=1).font = Font(bold=True, color=argb("fg"))
    ws.cell(row=r, column=1).border = Border(bottom=_THIN)


def _exceptions(ws, result: object, rows: list) -> None:
    ws.column_dimensions["A"].width = 32
    for index in range(2, 7):
        ws.column_dimensions[get_column_letter(index)].width = 16
    _section(ws, "① 异常态（stale / manual / missing）")
    for rec, grade, trust in rows:
        if trust == "fresh":
            continue
        ws.append([f"{_get(rec, 'brand', '—')}·{_get(rec, 'shop_name', '—')}", _get(rec, "platform", "—"),
                   TRUST_LABEL[trust], _get(rec, "degraded_reason") or "抓取失败",
                   _get(rec, "source_date") or "", _get(rec, "stale_days") or ""])
    for label, key, hint in (("② 档位待定", "tier_pending", "请用 classify 逐项定档"),
                             ("③ 计价待定", "unit_pending", "人均价恒「待定」，请确认计价单位")):
        _section(ws, label)
        value = _get(result, key, 0)
        count = value if isinstance(value, int) else len(value or [])
        ws.append([f"共 {count} 项", "", "", hint, "", ""])
        if not isinstance(value, int):  # 兼容旧调用传入明细列表
            for item in value or []:
                ws.append([_get(item, "title") or _get(item, "name") or "未命名套餐",
                           _get(item, "platform") or "",
                           yuan(_get(item, "price_cents")) or _get(item, "price") or "",
                           "待定" if key == "unit_pending" else "", _get(item, "url") or ""])
    _section(ws, "④ 已下架")
    for item in (_get(result, "discontinued", []) or []):
        ws.append([_get(item, "name") or "—", _get(item, "platform") or "",
                   yuan(_get(item, "last_price_cents")), _get(item, "confirmed_date") or ""])


def _readme(ws) -> None:
    _header(ws, 1, ["字段 / 口径", "说明"], [22, 80])
    for name, desc in _DICT.items():
        ws.append([name, desc])
    for line in (
        "涨红跌绿：>0 红（price-up），<0 绿（price-down），色值见 design-tokens.css（与 HTML / CLI 同源）。",
        "任何状态不得把价格画成 0；缺失写 missing，沿用保留末价并标注天数。",
        "sub_level 为运行时派生审计列，不是数据库枚举，禁止上屏。",
        f"生成版本 {VERSION} · 与日报同名同数据源。",
    ):
        ws.append(["", line])


def render_excel(result: object, path: str | Path, report_date: str | None = None) -> Path:
    day = report_date or datetime.now().strftime("%Y-%m-%d")
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    rows = _records(result)
    wb = Workbook()
    ws = wb.active
    ws.title = "01_今日结论"
    _conclusion(ws, result, day, rows)
    _detail(wb.create_sheet("02_价格明细"), result, day, rows)
    _analysis(wb.create_sheet("03_价差与变动"), result, rows)
    _exceptions(wb.create_sheet("04_异常清单"), result, rows)
    _readme(wb.create_sheet("README"))
    wb.save(target)
    return target

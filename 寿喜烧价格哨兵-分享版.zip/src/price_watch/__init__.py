"""price_watch — 上海高阶寿喜烧自助全网最低价监控（本地脚本）。

分层：orchestrator -> fetchers/parsers/domain -> storage/repositories -> utils。
金额全链路整数分；round 仅允许出现在 utils/money.py。
"""

__version__ = "1.0.0"

"""brands 表数据访问（无业务逻辑）。"""

from __future__ import annotations

import json
import sqlite3
from typing import Iterable

BRAND_NAMES = ("牛New寿喜烧", "一绪寿喜烧")


def ensure_brands(conn: sqlite3.Connection, names: Iterable[str] = BRAND_NAMES) -> dict[str, int]:
    """幂等播种品牌，返回 {品牌名: id}。"""
    result: dict[str, int] = {}
    for name in names:
        conn.execute(
            "INSERT OR IGNORE INTO brands(name, keyword_variants_json) VALUES(?,?)",
            (name, json.dumps([name.replace("寿喜烧", ""), name], ensure_ascii=False)),
        )
        row = conn.execute("SELECT id FROM brands WHERE name=?", (name,)).fetchone()
        if row is not None:
            result[name] = int(row["id"])
    conn.commit()
    return result


def list_brands(conn: sqlite3.Connection, active_only: bool = True) -> list[sqlite3.Row]:
    sql = "SELECT * FROM brands"
    if active_only:
        sql += " WHERE is_active=1"
    return list(conn.execute(sql + " ORDER BY id"))


def get_brand(conn: sqlite3.Connection, name: str) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM brands WHERE name=?", (name,)).fetchone()

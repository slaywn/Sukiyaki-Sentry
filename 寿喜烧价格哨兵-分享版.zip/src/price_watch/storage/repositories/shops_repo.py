"""shops / skus 表数据访问（无业务逻辑）。

约定：shops.is_active 同时承担「bootstrap 逐店勾选确认」语义——
种子导入时置 0，用户勾选后置 1；未确认门店不参与跑批（F12 门禁）。
"""

from __future__ import annotations

import json
import sqlite3
from collections.abc import Mapping
from typing import Any

from ...domain.level import LevelDecision


def upsert_shop(
    conn: sqlite3.Connection,
    *,
    brand_id: int,
    name: str,
    city: str,
    district: str | None = None,
    address: str | None = None,
    confirmed: bool = False,
) -> int:
    conn.execute(
        "INSERT INTO shops(brand_id,city,district,name,address,is_active) "
        "VALUES(?,?,?,?,?,?) ON CONFLICT DO NOTHING",
        (brand_id, city, district, name, address, int(confirmed)),
    )
    row = conn.execute(
        "SELECT id FROM shops WHERE brand_id=? AND name=?", (brand_id, name)
    ).fetchone()
    assert row is not None
    return int(row["id"])


def confirm_shop(conn: sqlite3.Connection, shop_id: int, confirmed: bool = True) -> None:
    conn.execute("UPDATE shops SET is_active=?, updated_at=datetime('now','localtime') WHERE id=?",
                 (int(confirmed), shop_id))
    conn.commit()


def list_shops(
    conn: sqlite3.Connection, *, brand_id: int | None = None, active_only: bool = False
) -> list[sqlite3.Row]:
    clauses, params = [], []
    if brand_id is not None:
        clauses.append("brand_id=?")
        params.append(brand_id)
    if active_only:
        clauses.append("is_active=1")
    sql = "SELECT * FROM shops"
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    return list(conn.execute(sql + " ORDER BY id", params))


def find_confirmed_shop(
    conn: sqlite3.Connection, brand_name: str | None, shop_name: str | None
) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT s.id FROM shops s JOIN brands b ON b.id=s.brand_id "
        "WHERE b.name=? AND s.name=? AND s.is_active=1 LIMIT 1",
        (brand_name, shop_name),
    ).fetchone()


def has_confirmed_shops(conn: sqlite3.Connection) -> bool:
    row = conn.execute("SELECT 1 FROM shops WHERE is_active=1 LIMIT 1").fetchone()
    return row is not None


def ensure_sku(
    conn: sqlite3.Connection,
    *,
    shop_id: int,
    name: str,
    decision: LevelDecision | None = None,
) -> int:
    existing = conn.execute(
        "SELECT id FROM skus WHERE shop_id=? AND name=?", (shop_id, name)
    ).fetchone()
    if existing is None:
        conn.execute("INSERT INTO skus(shop_id,name) VALUES(?,?)", (shop_id, name))
        row = conn.execute(
            "SELECT id FROM skus WHERE shop_id=? AND name=?", (shop_id, name)
        ).fetchone()
    else:
        row = existing
    sku_id = int(row["id"])
    if decision is not None:
        apply_decision(conn, sku_id, decision)
    conn.commit()
    return sku_id


def apply_decision(conn: sqlite3.Connection, sku_id: int, decision: LevelDecision) -> None:
    """把 domain 的定档结论映射到 skus 列（纯映射，不重算档位）。"""
    conn.execute(
        "UPDATE skus SET level=?, classification_status=?, level_source=?, "
        "level_confidence=?, map_version=?, level_candidates_json=?, "
        "updated_at=datetime('now','localtime') WHERE id=?",
        (
            decision.level,
            decision.classification_status,
            decision.level_source,
            decision.level_confidence,
            decision.map_version,
            json.dumps(list(decision.candidates), ensure_ascii=False),
            sku_id,
        ),
    )
    conn.commit()


def get_sku(conn: sqlite3.Connection, sku_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM skus WHERE id=?", (sku_id,)).fetchone()


def list_classified_skus(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return list(conn.execute(
        "SELECT * FROM skus WHERE classification_status='classified' AND level IS NOT NULL"
    ))


def to_dict(row: sqlite3.Row) -> dict[str, Any]:
    return dict(row)


def parse_candidates(row: Mapping[str, Any]) -> list[int]:
    return list(json.loads(row.get("level_candidates_json") or "[]"))

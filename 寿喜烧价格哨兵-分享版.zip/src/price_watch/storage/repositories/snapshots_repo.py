"""price_snapshots 数据访问 —— 幂等 upsert 与覆盖物化的唯一实现点（data-model §5.1）。

规则表：无行->插入；stale/missing->fresh/manual 升级；fresh->fresh 覆盖（价差>10 元留
cache_suspected）；fresh->stale/missing 拒绝；manual 最高优先级（manual->manual 留痕）。
本模块只承载存储保护，不重算档位/人均/可信度；入参值由 domain 层算好。
"""

from __future__ import annotations

import sqlite3
from collections.abc import Iterable, Mapping
from datetime import date, timedelta
from typing import Any

from ...utils.money import cents_diff_exceeds

COLUMNS = (
    "platform_deal_id", "snapshot_date", "sale_price_cents", "member_price_cents",
    "cond_price_cents", "cond_type", "cond_note", "unit_type", "persons",
    "per_capita_cents", "member_per_capita_cents", "extra_fee_cents",
    "effective_per_capita_cents", "usable_time_window", "booking_required",
    "extra_note", "verify_mode", "degraded_reason", "title_observed",
    "trust_level", "source_date", "fetch_run_id", "manual_note", "error_code",
    "captured_at",
)
TIER_COLUMN = {
    "P_MAIN": "sale_price_cents",
    "P_MEMBER": "member_price_cents",
    "P_COND": "cond_price_cents",
}
_COPY_COLUMNS = (
    "sale_price_cents", "member_price_cents", "cond_price_cents", "cond_type",
    "cond_note", "unit_type", "persons", "per_capita_cents",
    "member_per_capita_cents", "extra_fee_cents", "effective_per_capita_cents",
    "usable_time_window", "booking_required", "extra_note", "title_observed",
)


def _insert(conn: sqlite3.Connection, deal_id: int, day: str, values: Mapping[str, Any]) -> None:
    payload = dict(values)
    payload["platform_deal_id"] = deal_id
    payload["snapshot_date"] = day
    payload.setdefault("unit_type", "UNKNOWN")
    payload.setdefault("verify_mode", "single")
    marks = ",".join("?" for _ in COLUMNS)
    names = ",".join(COLUMNS)
    # SQL 关键字为字面量；列名/占位符来自模块常量 COLUMNS，不接受任何外部输入。
    statement = "INSERT INTO price_snapshots(" + names + ") VALUES(" + marks + ")"
    conn.execute(statement, [payload.get(col) for col in COLUMNS])
    conn.commit()


def _patch(conn: sqlite3.Connection, deal_id: int, day: str, patch: Mapping[str, Any]) -> None:
    keys = [k for k in patch if k in COLUMNS and k not in ("platform_deal_id", "snapshot_date")]
    if not keys:
        return
    assignments = ",".join(key + "=?" for key in keys)
    # 列名只从模块常量 COLUMNS 白名单取；值与条件一律参数占位（E02）。
    statement = ("UPDATE price_snapshots SET " + assignments
                 + ", updated_at=datetime('now','localtime') "
                 + "WHERE platform_deal_id=? AND snapshot_date=?")
    conn.execute(statement, [patch[k] for k in keys] + [deal_id, day])
    conn.commit()


def _merge_reason(old: str | None, new: str | None, cache_suspected: bool) -> str | None:
    parts = [p.strip() for p in (old or "").split(",") if p.strip()]
    for part in (new or "").split(","):
        if part.strip() and part.strip() not in parts:
            parts.append(part.strip())
    if cache_suspected and "cache_suspected" not in parts:
        parts.append("cache_suspected")
    return ",".join(parts) or None


def upsert(
    conn: sqlite3.Connection,
    deal_id: int,
    day: str,
    values: Mapping[str, Any],
    *,
    tier: str | None = None,
    cache_diff_threshold_cents: int = 1000,
) -> str:
    """按保护规则写一行；返回 inserted/upgraded/replaced/kept_fresh/kept_manual/manual_updated。"""
    if tier is not None and tier not in TIER_COLUMN:
        raise ValueError(f"非法 tier: {tier}")
    existing = conn.execute(
        "SELECT * FROM price_snapshots WHERE platform_deal_id=? AND snapshot_date=?",
        (deal_id, day),
    ).fetchone()
    if existing is None:
        _insert(conn, deal_id, day, values)
        return "inserted"
    old_trust = str(existing["trust_level"])
    new_trust = str(values.get("trust_level") or "fresh")
    if new_trust == "manual":
        patch = dict(values)
        patch["trust_level"] = "manual"
        patch["source_date"] = None
        patch["fetch_run_id"] = None
        patch["error_code"] = None
        if tier:
            tier_col = TIER_COLUMN[tier]
            patch[tier_col] = values.get(tier_col)
        _patch(conn, deal_id, day, patch)
        return "manual_updated" if old_trust == "manual" else "upgraded"
    if old_trust == "manual":
        return "kept_manual"
    if old_trust == "fresh" and new_trust in ("stale", "missing"):
        return "kept_fresh"
    patch = dict(values)
    if old_trust == "fresh" and new_trust == "fresh":
        suspected = cents_diff_exceeds(
            existing["sale_price_cents"], values.get("sale_price_cents"),
            cache_diff_threshold_cents,
        )
        patch["degraded_reason"] = _merge_reason(
            existing["degraded_reason"], values.get("degraded_reason"), suspected
        )
        _patch(conn, deal_id, day, patch)
        return "replaced"
    _patch(conn, deal_id, day, patch)
    return "upgraded"


def latest_success(
    conn: sqlite3.Connection, deal_id: int, day: str, max_days: int
) -> sqlite3.Row | None:
    floor = (date.fromisoformat(day) - timedelta(days=max_days)).isoformat()
    return conn.execute(
        "SELECT * FROM price_snapshots WHERE platform_deal_id=? AND snapshot_date BETWEEN ? AND ? "
        "AND trust_level IN ('fresh','manual') AND sale_price_cents IS NOT NULL "
        "ORDER BY snapshot_date DESC LIMIT 1",
        (deal_id, floor, day),
    ).fetchone()


def same_day_sale(conn: sqlite3.Connection, deal_id: int, day: str) -> int | None:
    """取同日已存在的 P_MAIN，供同日二次抓取的 cache_suspected 判定。"""
    row = conn.execute(
        "SELECT sale_price_cents FROM price_snapshots "
        "WHERE platform_deal_id=? AND snapshot_date=?", (deal_id, day),
    ).fetchone()
    return row["sale_price_cents"] if row else None


def has_row(conn: sqlite3.Connection, deal_id: int, day: str) -> bool:
    return conn.execute(
        "SELECT 1 FROM price_snapshots WHERE platform_deal_id=? AND snapshot_date=?",
        (deal_id, day),
    ).fetchone() is not None


def materialize(
    conn: sqlite3.Connection,
    deal_ids: Iterable[int],
    day: str,
    *,
    max_stale_days: int,
    run_id: int | None,
    captured_at: str,
) -> dict[str, int]:
    """覆盖物化：当日无行的应采 deal 补一行 stale 或 missing；已有行不动。"""
    counts = {"stale": 0, "missing": 0, "kept": 0}
    for deal_id in deal_ids:
        if has_row(conn, deal_id, day):
            counts["kept"] += 1
            continue
        source = latest_success(conn, deal_id, day, max_stale_days)
        if source is None:
            _insert(conn, deal_id, day, {
                "unit_type": "UNKNOWN", "verify_mode": "single", "trust_level": "missing",
                "error_code": "materialize_missing", "captured_at": captured_at,
                "fetch_run_id": run_id,
            })
            counts["missing"] += 1
            continue
        values = {col: source[col] for col in _COPY_COLUMNS}
        values.update({
            "trust_level": "stale", "source_date": source["snapshot_date"],
            "verify_mode": "single", "degraded_reason": None, "error_code": None,
            "manual_note": None, "fetch_run_id": run_id, "captured_at": captured_at,
        })
        _insert(conn, deal_id, day, values)
        counts["stale"] += 1
    return counts


def count_by_trust(conn: sqlite3.Connection, day: str) -> dict[str, int]:
    rows = conn.execute(
        "SELECT trust_level, COUNT(*) n FROM price_snapshots WHERE snapshot_date=? "
        "GROUP BY trust_level", (day,),
    ).fetchall()
    counts = {key: 0 for key in ("fresh", "stale", "manual", "missing")}
    for row in rows:
        counts[str(row["trust_level"])] = int(row["n"])
    return counts


def query_daily_lowest(conn: sqlite3.Connection, day: str) -> list[dict[str, Any]]:
    # 带出该 deal 自己的抓取时刻与来源日，供即时页 B 区行内时间/沿用天数使用。
    rows = conn.execute(
        "SELECT v.*, s.captured_at, s.source_date, s.error_code "
        "FROM v_daily_lowest v JOIN price_snapshots s "
        "ON s.platform_deal_id=v.platform_deal_id AND s.snapshot_date=v.snapshot_date "
        "WHERE v.snapshot_date=?", (day,),
    ).fetchall()
    return [dict(row) for row in rows]


def query_stale_lowest(conn: sqlite3.Connection, day: str) -> list[dict[str, Any]]:
    """沿用值候选（D 级）：与 v_daily_lowest 同粒度，供即时页 B 区；不挂最低价徽标。"""
    rows = conn.execute(
        "WITH c AS ("
        " SELECT s.snapshot_date, b.name brand_name, sh.name shop_name, k.level, ps.platform,"
        " ps.id platform_deal_id, ps.url, ps.is_starred, s.unit_type, s.captured_at,"
        " s.source_date, s.effective_per_capita_cents,"
        " CASE WHEN s.member_per_capita_cents IS NOT NULL AND"
        "  (s.per_capita_cents IS NULL OR s.member_per_capita_cents<s.per_capita_cents)"
        "  THEN s.member_per_capita_cents ELSE s.per_capita_cents END board_per_capita"
        " FROM price_snapshots s JOIN platform_deals ps ON ps.id=s.platform_deal_id"
        " JOIN skus k ON k.id=ps.sku_id JOIN shops sh ON sh.id=k.shop_id"
        " JOIN brands b ON b.id=sh.brand_id"
        " WHERE s.snapshot_date=? AND s.trust_level='stale'"
        "  AND s.unit_type IN ('SINGLE','MULTI_N') AND ps.status='active'"
        "  AND k.classification_status='classified' AND k.level IS NOT NULL"
        "  AND (s.per_capita_cents IS NOT NULL OR s.member_per_capita_cents IS NOT NULL)"
        ") SELECT * FROM (SELECT c.*, ROW_NUMBER() OVER ("
        " PARTITION BY c.snapshot_date,c.brand_name,c.shop_name,c.level"
        " ORDER BY c.board_per_capita ASC) rn FROM c) WHERE rn=1", (day,),
    ).fetchall()
    return [dict(row) for row in rows]


def previous_board_prices(
    conn: sqlite3.Connection, deal_ids: Iterable[int], day: str
) -> dict[int, int]:
    """每个 deal 最近一次有效抓取(含人工)的主榜人均，用于 delta_cents；一次查询避免 N+1。"""
    values = list(deal_ids)
    if not values:
        return {}
    marks = ",".join("?" for _ in values)
    statement = (
        "WITH ranked AS (SELECT platform_deal_id, per_capita_cents, member_per_capita_cents,"
        " ROW_NUMBER() OVER (PARTITION BY platform_deal_id ORDER BY snapshot_date DESC) rn"
        " FROM price_snapshots WHERE platform_deal_id IN (" + marks + ") AND snapshot_date<?"
        " AND trust_level IN ('fresh','manual') AND unit_type IN ('SINGLE','MULTI_N')"
        " AND (per_capita_cents IS NOT NULL OR member_per_capita_cents IS NOT NULL))"
        " SELECT * FROM ranked WHERE rn=1"
    )
    result: dict[int, int] = {}
    for row in conn.execute(statement, values + [day]):
        options = [v for v in (row["per_capita_cents"], row["member_per_capita_cents"])
                   if v is not None]
        if options:
            result[int(row["platform_deal_id"])] = min(options)
    return result


def previous_captured_at(conn: sqlite3.Connection, day: str, run_started_at: str) -> str | None:
    row = conn.execute(
        "SELECT captured_at FROM price_snapshots WHERE snapshot_date<=? AND captured_at<? "
        "ORDER BY captured_at DESC LIMIT 1", (day, run_started_at),
    ).fetchone()
    return str(row["captured_at"]) if row else None


def query_pending_review(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    return [dict(row) for row in conn.execute("SELECT * FROM v_pending_review")]


def query_discontinued(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    return [dict(row) for row in conn.execute("SELECT * FROM v_discontinued")]


def query_coverage(conn: sqlite3.Connection, day: str) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT * FROM v_daily_coverage WHERE snapshot_date=?", (day,)
    ).fetchall()
    return [dict(row) for row in rows]

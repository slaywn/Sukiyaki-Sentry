"""platform_deals 表数据访问（无业务逻辑；停售/标星判定由 domain/orchestrator 决定）。"""

from __future__ import annotations

import sqlite3
from collections.abc import Iterable

PLATFORMS = ("meituan", "dianping", "douyin")
ACTIVE_STATUSES = ("active",)


def upsert_deal(
    conn: sqlite3.Connection,
    *,
    sku_id: int,
    platform: str,
    platform_deal_id: str,
    url: str,
    title_observed: str | None = None,
    today: str,
) -> int:
    conn.execute(
        "INSERT INTO platform_deals"
        "(sku_id,platform,platform_deal_id,url,title_observed,status,first_seen,last_seen) "
        "VALUES(?,?,?,?,?,'active',?,?) "
        "ON CONFLICT(platform,platform_deal_id) DO UPDATE SET "
        "url=excluded.url, title_observed=excluded.title_observed, "
        "last_seen=excluded.last_seen, updated_at=datetime('now','localtime')",
        (sku_id, platform, platform_deal_id, url, title_observed, today, today),
    )
    conn.commit()
    row = conn.execute(
        "SELECT id FROM platform_deals WHERE platform=? AND platform_deal_id=?",
        (platform, platform_deal_id),
    ).fetchone()
    assert row is not None
    return int(row["id"])


def get_deal(conn: sqlite3.Connection, platform: str, platform_deal_id: str) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM platform_deals WHERE platform=? AND platform_deal_id=?",
        (platform, platform_deal_id),
    ).fetchone()


def get_deal_by_id(conn: sqlite3.Connection, deal_id: int) -> sqlite3.Row | None:
    return conn.execute("SELECT * FROM platform_deals WHERE id=?", (deal_id,)).fetchone()


def set_status(
    conn: sqlite3.Connection, deal_id: int, status: str, discontinued_at: str | None = None
) -> None:
    if status not in ("active", "discontinued", "paused"):
        raise ValueError(f"非法 status: {status}")
    conn.execute(
        "UPDATE platform_deals SET status=?, discontinued_at=?, "
        "updated_at=datetime('now','localtime') WHERE id=?",
        (status, discontinued_at, deal_id),
    )
    conn.commit()


def set_starred(conn: sqlite3.Connection, deal_id: int, starred: bool) -> None:
    conn.execute(
        "UPDATE platform_deals SET is_starred=?, "
        "updated_at=datetime('now','localtime') WHERE id=?",
        (int(starred), deal_id),
    )
    conn.commit()


def list_active(
    conn: sqlite3.Connection,
    *,
    platform: str | None = None,
    brand_id: int | None = None,
) -> list[sqlite3.Row]:
    clauses = ["pd.status='active'", "sh.is_active=1",
               "k.classification_status='classified'", "k.level IS NOT NULL"]
    params: list[object] = []
    if platform:
        clauses.append("pd.platform=?")
        params.append(platform)
    if brand_id is not None:
        clauses.append("sh.brand_id=?")
        params.append(brand_id)
    return list(conn.execute(
        "SELECT pd.*, k.id sku_id, k.name sku_name, k.level, sh.name shop_name, "
        "sh.district, b.name brand_name, b.id brand_id "
        "FROM platform_deals pd JOIN skus k ON k.id=pd.sku_id "
        "JOIN shops sh ON sh.id=k.shop_id JOIN brands b ON b.id=sh.brand_id "
        "WHERE " + " AND ".join(clauses) + " ORDER BY pd.id",
        params,
    ))


def list_starred(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return list(conn.execute(
        "SELECT * FROM platform_deals WHERE is_starred=1 AND status='active' ORDER BY id"
    ))


def list_recovery(conn: sqlite3.Connection, date: str) -> list[sqlite3.Row]:
    return list(conn.execute(
        "SELECT DISTINCT pd.* FROM platform_deals pd JOIN price_snapshots s "
        "ON s.platform_deal_id=pd.id AND s.snapshot_date=? "
        "WHERE pd.status='active' AND s.trust_level IN ('stale','missing')",
        (date,),
    ))


def list_by_ids(conn: sqlite3.Connection, ids: Iterable[int]) -> list[sqlite3.Row]:
    values = list(ids)
    if not values:
        return []
    marks = ",".join("?" for _ in values)
    # 仅拼接与 id 数量等长的 '?' 占位符，id 本身全部参数绑定（E02）。
    statement = "SELECT * FROM platform_deals WHERE id IN (" + marks + ")"
    return list(conn.execute(statement, values))


def list_discontinued(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return list(conn.execute("SELECT * FROM platform_deals WHERE status='discontinued'"))

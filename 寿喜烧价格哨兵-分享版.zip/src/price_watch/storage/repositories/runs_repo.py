"""fetch_runs 表数据访问（无业务逻辑）。"""

from __future__ import annotations

import sqlite3
from datetime import date, timedelta

VALID_TRIGGERS = (
    "scheduled_main", "scheduled_retry", "manual_quick", "manual_full",
)


def start_run(
    conn: sqlite3.Connection,
    *,
    run_date: str,
    platform: str,
    trigger_type: str,
    started_at: str,
) -> int:
    if trigger_type not in VALID_TRIGGERS:
        raise ValueError(f"非法 trigger_type: {trigger_type}")
    cur = conn.execute(
        "INSERT INTO fetch_runs(run_date,platform,trigger_type,status,started_at) "
        "VALUES(?,?,?,'partial',?)",
        (run_date, platform, trigger_type, started_at),
    )
    conn.commit()
    return int(cur.lastrowid)


def finish_run(
    conn: sqlite3.Connection,
    run_id: int,
    *,
    status: str,
    deals_attempted: int = 0,
    deals_ok: int = 0,
    pages_used: int = 0,
    error_code: str | None = None,
    error_summary: str | None = None,
    finished_at: str,
) -> None:
    if status not in ("ok", "partial", "failed", "aborted", "paused"):
        raise ValueError(f"非法 run status: {status}")
    conn.execute(
        "UPDATE fetch_runs SET status=?, deals_attempted=?, deals_ok=?, pages_used=?, "
        "error_code=?, error_summary=?, finished_at=? WHERE id=?",
        (status, deals_attempted, deals_ok, pages_used, error_code, error_summary,
         finished_at, run_id),
    )
    conn.commit()


def consecutive_failed_days(
    conn: sqlite3.Connection, platform: str, today: str, limit: int = 7
) -> int:
    """从今天往前数连续 failed/aborted 的天数（去重按天计）。"""
    rows = conn.execute(
        "SELECT DISTINCT run_date FROM fetch_runs WHERE platform=? AND run_date<=? "
        "AND status IN ('failed','aborted') ORDER BY run_date DESC LIMIT ?",
        (platform, today, limit),
    ).fetchall()
    expected = date.fromisoformat(today)
    count = 0
    for row in rows:
        if date.fromisoformat(str(row["run_date"])) != expected - timedelta(days=count):
            break
        count += 1
    return count


def list_runs(conn: sqlite3.Connection, run_date: str) -> list[sqlite3.Row]:
    return list(conn.execute(
        "SELECT * FROM fetch_runs WHERE run_date=? ORDER BY platform", (run_date,)
    ))

"""数据层：SQLite 连接、schema 迁移与 repositories（无业务逻辑）。"""

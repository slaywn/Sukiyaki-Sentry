"""SQLite 连接与 schema 迁移。DDL 唯一契约 = docs/data-model.md §3/§7。

WAL + 外键 + 顺序版本号迁移。trigger_type 采用 SPEC §5 四值
(scheduled_main/scheduled_retry/manual_quick/manual_full)；data-model.md v1.3 的三值
(scheduled/manual_fast/manual_full) 为旧稿，已在交接中报备 team-lead。
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

SCHEMA_VERSION = 1

DDL_TABLES = """
CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS brands (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    keyword_variants_json TEXT NOT NULL DEFAULT '[]',
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS shops (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    brand_id INTEGER NOT NULL REFERENCES brands(id),
    city TEXT NOT NULL, district TEXT, name TEXT NOT NULL, address TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_shops_brand ON shops(brand_id) WHERE is_active=1;
CREATE INDEX IF NOT EXISTS idx_shops_district ON shops(district);
CREATE UNIQUE INDEX IF NOT EXISTS uq_shops_brand_name ON shops(brand_id, name);
CREATE TABLE IF NOT EXISTS skus (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    shop_id INTEGER NOT NULL REFERENCES shops(id),
    name TEXT NOT NULL,
    level INTEGER CHECK (level BETWEEN 1 AND 6),
    classification_status TEXT NOT NULL DEFAULT 'unclassified'
        CHECK (classification_status IN ('classified','unclassified')),
    level_source TEXT CHECK (level_source IN ('map','manual','price_rank','keyword')),
    level_confidence TEXT CHECK (level_confidence IN ('confirmed','high','medium','low')),
    map_version TEXT,
    level_candidates_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_skus_shop ON skus(shop_id);
CREATE INDEX IF NOT EXISTS idx_skus_level ON skus(level, classification_status);
CREATE UNIQUE INDEX IF NOT EXISTS uq_skus_shop_name ON skus(shop_id, name);
CREATE TABLE IF NOT EXISTS platform_deals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sku_id INTEGER NOT NULL REFERENCES skus(id),
    platform TEXT NOT NULL CHECK (platform IN ('meituan','dianping','douyin')),
    platform_deal_id TEXT NOT NULL, url TEXT NOT NULL, title_observed TEXT,
    status TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active','discontinued','paused')),
    is_starred INTEGER NOT NULL DEFAULT 0,
    discontinued_at TEXT, first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (platform, platform_deal_id)
);
CREATE INDEX IF NOT EXISTS idx_deals_sku ON platform_deals(sku_id) WHERE status='active';
CREATE INDEX IF NOT EXISTS idx_deals_status ON platform_deals(status);
CREATE INDEX IF NOT EXISTS idx_deals_starred ON platform_deals(is_starred) WHERE is_starred=1 AND status='active';
CREATE TABLE IF NOT EXISTS fetch_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_date TEXT NOT NULL, platform TEXT NOT NULL,
    trigger_type TEXT NOT NULL DEFAULT 'scheduled_main'
        CHECK (trigger_type IN ('scheduled_main','scheduled_retry','manual_quick','manual_full')),
    status TEXT NOT NULL CHECK (status IN ('ok','partial','failed','aborted','paused')),
    deals_attempted INTEGER NOT NULL DEFAULT 0,
    deals_ok INTEGER NOT NULL DEFAULT 0,
    pages_used INTEGER NOT NULL DEFAULT 0,
    error_code TEXT, error_summary TEXT,
    started_at TEXT NOT NULL, finished_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_runs_date ON fetch_runs(run_date, platform);
CREATE TABLE IF NOT EXISTS price_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    platform_deal_id INTEGER NOT NULL REFERENCES platform_deals(id),
    snapshot_date TEXT NOT NULL,
    sale_price_cents INTEGER, member_price_cents INTEGER, cond_price_cents INTEGER,
    cond_type TEXT CHECK (cond_type IN ('new_customer','coupon','seckill','bank')),
    cond_note TEXT,
    unit_type TEXT NOT NULL DEFAULT 'UNKNOWN'
        CHECK (unit_type IN ('SINGLE','MULTI_N','PER_TABLE','VOUCHER','FAMILY','PAY_AT_STORE','UNKNOWN')),
    persons INTEGER,
    per_capita_cents INTEGER, member_per_capita_cents INTEGER,
    extra_fee_cents INTEGER, effective_per_capita_cents INTEGER,
    usable_time_window TEXT, booking_required INTEGER, extra_note TEXT,
    verify_mode TEXT NOT NULL DEFAULT 'single' CHECK (verify_mode IN ('dual','single')),
    degraded_reason TEXT, title_observed TEXT,
    trust_level TEXT NOT NULL CHECK (trust_level IN ('fresh','stale','manual','missing')),
    source_date TEXT, fetch_run_id INTEGER REFERENCES fetch_runs(id),
    manual_note TEXT, error_code TEXT, captured_at TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (platform_deal_id, snapshot_date)
);
CREATE INDEX IF NOT EXISTS idx_snapshots_date ON price_snapshots(snapshot_date);
CREATE INDEX IF NOT EXISTS idx_snapshots_trust ON price_snapshots(snapshot_date, trust_level);
"""

# 视图保持通用：min_level 过滤在 domain/lowest.py 做；cond 永不参与最低价。
DDL_VIEWS = """
CREATE VIEW IF NOT EXISTS v_daily_coverage AS
SELECT b.id brand_id, b.name brand_name, sh.district, s.snapshot_date, ps.platform,
 COUNT(*) deals_total,
 SUM(CASE WHEN s.trust_level IN ('fresh','manual') THEN 1 ELSE 0 END) deals_fresh,
 SUM(CASE WHEN s.trust_level='stale' THEN 1 ELSE 0 END) deals_stale,
 SUM(CASE WHEN s.trust_level='missing' THEN 1 ELSE 0 END) deals_missing
FROM price_snapshots s JOIN platform_deals ps ON ps.id=s.platform_deal_id
JOIN skus k ON k.id=ps.sku_id JOIN shops sh ON sh.id=k.shop_id
JOIN brands b ON b.id=sh.brand_id
WHERE ps.status='active' AND k.classification_status='classified' AND k.level IS NOT NULL
GROUP BY b.id,b.name,sh.district,s.snapshot_date,ps.platform;
CREATE VIEW IF NOT EXISTS v_daily_lowest AS
WITH candidates AS (
 SELECT s.snapshot_date, b.id brand_id, b.name brand_name, sh.id shop_id,
  sh.name shop_name, sh.district, k.level, ps.platform, ps.id platform_deal_id,
  ps.url, s.unit_type, s.effective_per_capita_cents,
  CASE WHEN s.member_per_capita_cents IS NOT NULL AND
    (s.per_capita_cents IS NULL OR s.member_per_capita_cents<s.per_capita_cents)
    THEN s.member_per_capita_cents ELSE s.per_capita_cents END board_per_capita,
  CASE WHEN s.member_per_capita_cents IS NOT NULL AND
    (s.per_capita_cents IS NULL OR s.member_per_capita_cents<s.per_capita_cents)
    THEN 'P_MEMBER' ELSE 'P_MAIN' END winning_tier,
  s.trust_level, s.verify_mode, s.degraded_reason, ps.is_starred,
  CASE WHEN s.trust_level='manual' THEN 3 WHEN s.verify_mode='dual' THEN 1 ELSE 2 END quality_rank
 FROM price_snapshots s JOIN platform_deals ps ON ps.id=s.platform_deal_id
 JOIN skus k ON k.id=ps.sku_id JOIN shops sh ON sh.id=k.shop_id
 JOIN brands b ON b.id=sh.brand_id
 WHERE s.trust_level IN ('fresh','manual') AND s.unit_type IN ('SINGLE','MULTI_N')
  AND ps.status='active' AND k.classification_status='classified' AND k.level IS NOT NULL
  AND (s.per_capita_cents IS NOT NULL OR s.member_per_capita_cents IS NOT NULL)
)
SELECT * FROM (
 SELECT c.*, ROW_NUMBER() OVER (
   PARTITION BY c.snapshot_date,c.brand_id,c.shop_id,c.level
   ORDER BY c.board_per_capita ASC,c.quality_rank ASC) rn
 FROM candidates c
) WHERE rn=1;
CREATE VIEW IF NOT EXISTS v_cond_offers AS
SELECT s.snapshot_date, b.name brand_name, sh.name shop_name, sh.district, k.level,
 ps.platform, ps.url, k.name sku_name, s.cond_price_cents, s.cond_type, s.cond_note,
 s.persons, s.trust_level, s.verify_mode, s.degraded_reason
FROM price_snapshots s JOIN platform_deals ps ON ps.id=s.platform_deal_id
JOIN skus k ON k.id=ps.sku_id JOIN shops sh ON sh.id=k.shop_id
JOIN brands b ON b.id=sh.brand_id
WHERE s.cond_price_cents IS NOT NULL AND s.unit_type IN ('SINGLE','MULTI_N')
 AND ps.status='active' AND k.classification_status='classified' AND k.level IS NOT NULL;
CREATE VIEW IF NOT EXISTS v_pending_review AS
SELECT k.id sku_id, b.name brand_name, sh.name shop_name, sh.district, ps.platform,
 k.name sku_name, s.unit_type, k.level_candidates_json,
 s.snapshot_date last_seen_date,
 CASE WHEN k.classification_status='unclassified' THEN 'level_pending'
      ELSE 'unit_type_pending' END pending_kind
FROM skus k JOIN shops sh ON sh.id=k.shop_id JOIN brands b ON b.id=sh.brand_id
JOIN platform_deals ps ON ps.sku_id=k.id
LEFT JOIN price_snapshots s ON s.platform_deal_id=ps.id AND s.snapshot_date=(
 SELECT MAX(s2.snapshot_date) FROM price_snapshots s2 WHERE s2.platform_deal_id=ps.id)
WHERE k.classification_status='unclassified' OR s.unit_type='UNKNOWN';
CREATE VIEW IF NOT EXISTS v_discontinued AS
SELECT b.name brand_name, sh.name shop_name, k.name sku_name, k.level, ps.platform,
 ps.discontinued_at, s.snapshot_date last_snapshot_date, s.per_capita_cents last_per_capita_cents
FROM platform_deals ps JOIN skus k ON k.id=ps.sku_id JOIN shops sh ON sh.id=k.shop_id
JOIN brands b ON b.id=sh.brand_id JOIN price_snapshots s ON s.platform_deal_id=ps.id
 AND s.snapshot_date=(SELECT MAX(s2.snapshot_date) FROM price_snapshots s2
 WHERE s2.platform_deal_id=ps.id)
WHERE ps.status='discontinued';
"""


def connect(db_path: str | Path) -> sqlite3.Connection:
    """连接配置：WAL、外键、忙等待；Row 便于仓储层按列名取值。"""
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def migrate(conn: sqlite3.Connection) -> int:
    """顺序执行未应用迁移；返回当前 schema 版本。迁移文件化/可回滚由本版本基线承担。"""
    conn.executescript(DDL_TABLES)
    conn.execute(
        "INSERT OR IGNORE INTO schema_migrations(version) VALUES(?)", (SCHEMA_VERSION,)
    )
    conn.executescript(DDL_VIEWS)
    conn.commit()
    return SCHEMA_VERSION


def initialize(db_path: str | Path) -> sqlite3.Connection:
    conn = connect(db_path)
    migrate(conn)
    return conn

"""解析层数据模型与 XHR/DOM 双通道合并（纯函数，无 I/O）。"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, fields, replace
from datetime import datetime
import re
from typing import Any


def utc_now_iso() -> str:
    """统一时间戳：带时区的 ISO 8601（E14）。"""
    return datetime.now().astimezone().isoformat(timespec="seconds")


@dataclass(frozen=True)
class FetchTarget:
    """抓取目标：抓取层与解析层共用的数据模型，放在解析层避免两层循环依赖。"""

    platform: str
    platform_deal_id: str
    url: str
    brand: str = ""
    shop_name: str = ""
    title_observed: str = ""


@dataclass
class DealRaw:
    """一次抓取观察的原始结果。金额字段一律整数分，未抓到为 None（绝不写 0）。"""

    platform: str
    platform_deal_id: str
    url: str
    title_observed: str = ""
    sale_price_cents: int | None = None        # P_MAIN
    member_price_cents: int | None = None      # P_MEMBER
    cond_price_cents: int | None = None        # P_COND（永不进最低价）
    cond_type: str | None = None
    cond_note: str | None = None
    persons: int | None = None
    unit_type: str = "UNKNOWN"
    extra_fee_cents: int | None = None
    usable_time_window: str | None = None
    booking_required: int | None = None
    verify_mode: str = "single"                # dual = XHR+DOM 一致
    degraded_reason: str | None = None
    captured_at: str = ""
    brand: str | None = None                   # 供 domain/level 匹配，非存储列
    shop_name: str | None = None               # 供 domain/level 匹配，非存储列
    error_code: str | None = None


@dataclass
class FetchFailure:
    """抓取/解析失败记录。失败一律落 missing，不携带任何价格。"""

    platform: str
    platform_deal_id: str
    error_code: str                            # captcha_hit / login_expired / parse_conflict ...
    detail: str = ""
    url: str = ""
    brand: str | None = None
    shop_name: str | None = None
    title_observed: str = ""


@dataclass
class FetchPage:
    """一个平台一轮抓取的汇总。"""

    deals: list[DealRaw]
    failures: list[FetchFailure]
    captcha_hit: bool = False
    pages_used: int = 0
    error_code: str | None = None


_FILL_EMPTY = {"", "UNKNOWN", None}


def merge_channels(xhr: DealRaw | None, dom: DealRaw | None) -> DealRaw | FetchFailure:
    """XHR + DOM 双通道合并：一致->dual；仅一路->single；两路价冲突->missing。"""
    if xhr is None and dom is None:
        return FetchFailure("", "", "parse_empty", "XHR 与 DOM 均未取到价格")
    if xhr is not None and dom is not None:
        if (
            xhr.sale_price_cents is not None
            and dom.sale_price_cents is not None
            and xhr.sale_price_cents != dom.sale_price_cents
        ):
            return FetchFailure(
                xhr.platform, xhr.platform_deal_id, "parse_conflict",
                f"XHR={xhr.sale_price_cents} DOM={dom.sale_price_cents}", xhr.url,
                xhr.brand, xhr.shop_name, xhr.title_observed,
            )
        base = _fill_from(xhr, dom)
        base.verify_mode = "dual"
        return base
    only = xhr if xhr is not None else dom
    assert only is not None
    result = replace(only)
    result.verify_mode = "single"
    return result


def _fill_from(primary: DealRaw, secondary: DealRaw) -> DealRaw:
    """逐字段补空：primary 优先，空值取 secondary。"""
    values: dict[str, object] = {}
    for field in fields(DealRaw):
        a = getattr(primary, field.name)
        b = getattr(secondary, field.name)
        values[field.name] = b if a in _FILL_EMPTY and b not in _FILL_EMPTY else a
    result = DealRaw(**values)  # type: ignore[arg-type]
    if len(primary.title_observed) > len(result.title_observed):
        result.title_observed = primary.title_observed
    return result


_PRICE_RE = re.compile(r"(?:[¥￥]\s*|[\"']?price[\"']?\s*[:：]\s*)(\d+(?:\.\d{1,2})?)")
_COND_TYPES = (
    ("new_customer", ("新客", "首单", "限购")),
    ("coupon", ("券后", "代金券", "优惠券")),
    ("seckill", ("秒杀", "限时")),
    ("bank", ("银行", "银行卡", "支付立减")),
)


def first_present(payload: Mapping[str, Any] | None, keys: tuple[str, ...]) -> Any:
    if not isinstance(payload, Mapping):
        return None
    for key in keys:
        value = payload.get(key)
        if value not in (None, "", [], {}):
            return value
    return None


def normalize_cond_type(raw: Any) -> str | None:
    text = str(raw or "")
    for name, markers in _COND_TYPES:
        if any(marker in text for marker in markers):
            return name
    return None


def dom_price_text(html: str | None) -> str | None:
    """DOM 兜底取价：优先 data-price 属性，其次页面首现价格文本。"""
    if not html:
        return None
    attr = re.search(r"data-price\s*=\s*[\"']?([\d.]+)", html[:200_000], re.I)
    if attr:
        return attr.group(1)
    found = _PRICE_RE.search(html[:200_000])
    return found.group(1) if found else None


def positive_int(raw: Any) -> int | None:
    try:
        value = int(str(raw).strip())
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None


def flag(raw: Any) -> int | None:
    if raw is None or raw == "":
        return None
    return 1 if str(raw).lower() in ("1", "true", "yes", "需要", "是") else 0


def extract_xhr(
    payload: dict[str, Any] | None,
    target: FetchTarget,
    keys: Mapping[str, tuple[str, ...]],
) -> dict[str, Any] | None:
    """三平台共用的 XHR 字段抽取；金额在此一次性转成整数分。"""
    from ..utils.money import parse_fee_to_cents, parse_price_to_cents

    if not payload:
        return None
    sale = parse_price_to_cents(first_present(payload, keys["sale"]))
    if sale is None:
        return None
    note = first_present(payload, keys.get("cond_note", ()))
    return {
        "title_observed": str(first_present(payload, keys["title"]) or target.title_observed),
        "sale_price_cents": sale,
        "member_price_cents": parse_price_to_cents(first_present(payload, keys["member"])),
        "cond_price_cents": parse_price_to_cents(first_present(payload, keys["cond"])),
        "cond_type": normalize_cond_type(note),
        "cond_note": str(note) if note else None,
        "persons": positive_int(first_present(payload, keys.get("persons", ()))),
        "extra_fee_cents": parse_fee_to_cents(first_present(payload, keys.get("extra", ()))),
        "booking_required": flag(first_present(payload, keys.get("booking", ()))),
        "usable_time_window": first_present(payload, keys.get("window", ())),
    }


def extract_dom(target: FetchTarget, html: str | None) -> dict[str, Any] | None:
    """三平台共用的 DOM 兜底：仅取价标题与人数，其余字段留给 XHR 通道。"""
    from ..utils.money import parse_price_to_cents
    from ..domain.normalize import infer_unit_type_and_persons

    sale = parse_price_to_cents(dom_price_text(html))
    if sale is None:
        return None
    return {
        "title_observed": target.title_observed,
        "sale_price_cents": sale,
        "persons": infer_unit_type_and_persons(target.title_observed)[1],
    }


def to_failure(deal: DealRaw, error_code: str, detail: str = "") -> FetchFailure:
    """把一个未取到价格的 DealRaw 归一成失败记录（无价格外泄）。"""
    return FetchFailure(
        deal.platform, deal.platform_deal_id, error_code, detail, deal.url,
        deal.brand, deal.shop_name, deal.title_observed,
    )

"""抖音解析：独立失败域排在平台序列最后；不抓用户个人信息。"""

from __future__ import annotations

from typing import Any

from .models import FetchTarget, extract_dom, extract_xhr

KEYS: dict[str, tuple[str, ...]] = {
    "sale": ("minPrice", "discountPrice", "price", "salePrice"),
    "member": ("memberPrice", "vipPrice"),
    "cond": ("seckillPrice", "newCustomerPrice", "couponPrice"),
    "title": ("productName", "title", "name", "skuName"),
    "persons": ("persons", "personNum"),
    "extra": ("extraFee", "additionalFee"),
    "booking": ("needBooking", "bookingRequired", "booking_required"),
    "window": ("useTime", "time_window", "timeWindow"),
    "cond_note": ("promotionDesc", "condNote"),
}


def parse_xhr(payload: dict[str, Any] | None, target: FetchTarget) -> dict[str, Any] | None:
    return extract_xhr(payload, target, KEYS)


def parse_dom(html: str | None, target: FetchTarget) -> dict[str, Any] | None:
    return extract_dom(target, html)

"""美团解析：XHR JSON 优先，DOM 兜底（共用 models.extract_xhr/extract_dom）。"""

from __future__ import annotations

from typing import Any

from .models import FetchTarget, extract_dom, extract_xhr

KEYS: dict[str, tuple[str, ...]] = {
    "sale": ("salePrice", "sale_price", "groupPrice", "price", "dealPrice"),
    "member": ("memberPrice", "member_price", "vipPrice"),
    "cond": ("condPrice", "newCustomerPrice", "couponPrice"),
    "title": ("title", "dealTitle", "name"),
    "persons": ("persons", "personNum", "peopleCount"),
    "extra": ("extraFee", "extra_fee", "additionalFee"),
    "booking": ("bookingRequired", "booking_required", "needBooking"),
    "window": ("usableTimeWindow", "time_window", "timeWindow", "useTime"),
    "cond_note": ("condNote", "promotionTip", "useRule"),
}


def parse_xhr(payload: dict[str, Any] | None, target: FetchTarget) -> dict[str, Any] | None:
    return extract_xhr(payload, target, KEYS)


def parse_dom(html: str | None, target: FetchTarget) -> dict[str, Any] | None:
    return extract_dom(target, html)

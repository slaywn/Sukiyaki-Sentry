"""解析层：XHR JSON / DOM -> DealRaw；人均归一化在 domain 层完成。"""

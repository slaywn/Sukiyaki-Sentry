"""大众点评解析：XHR 优先，DOM 兜底；抽样对账由 orchestrator 触发。"""

from __future__ import annotations

from typing import Any

from .models import FetchTarget, extract_dom, extract_xhr

KEYS: dict[str, tuple[str, ...]] = {
    "sale": ("groupPrice", "price", "salePrice", "dealPrice"),
    "member": ("memberPrice", "vipPrice", "cardPrice"),
    "cond": ("promoPrice", "condPrice", "newCustomerPrice"),
    "title": ("dealTitle", "title", "name", "skuName"),
    "persons": ("persons", "personNum", "suitablePeople"),
    "extra": ("extraFee", "otherFee"),
    "booking": ("needBooking", "bookingRequired", "booking_required"),
    "window": ("useTimeDesc", "time_window", "timeWindow", "usableTimeWindow"),
    "cond_note": ("promotionTip", "condNote", "restriction"),
}


def parse_xhr(payload: dict[str, Any] | None, target: FetchTarget) -> dict[str, Any] | None:
    return extract_xhr(payload, target, KEYS)


def parse_dom(html: str | None, target: FetchTarget) -> dict[str, Any] | None:
    return extract_dom(target, html)

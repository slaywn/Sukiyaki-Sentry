"""可信度四态 + fresh 的 A/B/C 子态派生（纯函数，data-model.md §5.3）。"""

from __future__ import annotations

from typing import Iterable

DEGRADED_REASONS = (
    "extra_fee_missing",
    "time_window_missing",
    "booking_unknown",
    "cache_suspected",
)


def derive_degraded_reason(
    *,
    extra_fee_cents: int | None,
    usable_time_window: str | None,
    booking_required: int | None,
    cache_suspected: bool = False,
) -> str | None:
    """fresh 行的 C 级降级原因；多值逗号分隔，顺序固定。"""
    reasons = []
    if extra_fee_cents is None:
        reasons.append("extra_fee_missing")
    if usable_time_window is None:
        reasons.append("time_window_missing")
    if booking_required is None:
        reasons.append("booking_unknown")
    if cache_suspected:
        reasons.append("cache_suspected")
    return ",".join(reasons) or None


def normalize_degraded_reason(value: str | None) -> str | None:
    """去重、去空、按契约顺序重排；供同日重抓合并缓存疑似标记。"""
    if not value:
        return None
    parts = {p.strip() for p in value.split(",") if p.strip() in DEGRADED_REASONS}
    ordered = [r for r in DEGRADED_REASONS if r in parts]
    return ",".join(ordered) or None


def merge_degraded_reasons(*values: str | None) -> str | None:
    parts: list[str] = []
    for value in values:
        if value:
            parts.extend(value.split(","))
    return normalize_degraded_reason(",".join(parts))


def derive_grade(
    trust_level: str,
    verify_mode: str | None,
    degraded_reason: str | None,
) -> str:
    """fresh -> A(dual 且无降级) / B(single 无降级) / C(有降级)；
    stale -> D；missing -> X；manual -> manual。降级优先于双通道。"""
    reason = normalize_degraded_reason(degraded_reason)
    if trust_level == "fresh":
        if reason is not None:
            return "C"
        return "A" if verify_mode == "dual" else "B"
    if trust_level == "stale":
        return "D"
    if trust_level == "missing":
        return "X"
    if trust_level == "manual":
        return "manual"
    return "X"


BOARD_GRADES = frozenset({"A", "B", "C", "manual"})


def is_board_eligible(grade: str) -> bool:
    return grade in BOARD_GRADES


def quality_rank(grade: str, verify_mode: str | None) -> int:
    """同价排序：dual=1 > single=2 > manual=3；C 级沿用排位但带标记。"""
    if grade == "manual":
        return 3
    return 1 if verify_mode == "dual" else 2


def summarize_grades(grades: Iterable[str]) -> dict[str, int]:
    counts = {g: 0 for g in ("A", "B", "C", "D", "X", "manual")}
    for grade in grades:
        if grade in counts:
            counts[grade] += 1
    return counts

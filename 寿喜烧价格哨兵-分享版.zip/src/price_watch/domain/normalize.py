"""可比价归一化：计价形态/人数解析、人均守卫、三必抓字段（纯函数）。

硬规则：仅 SINGLE/MULTI_N 且 persons 非空才算人均；其余一律 NULL，禁止 ÷1/÷2 估算。
VOUCHER/FAMILY/PER_TABLE/PAY_AT_STORE/UNKNOWN 永不进主榜；UNKNOWN 进 v_pending_review。
"""

from __future__ import annotations

import re
from typing import Any, Mapping

from ..parsers.models import DealRaw
from ..utils.money import add_cents, cents_diff_exceeds, div_to_cents
from .trust import derive_degraded_reason

UNIT_TYPES = (
    "SINGLE", "MULTI_N", "PER_TABLE", "VOUCHER", "FAMILY", "PAY_AT_STORE", "UNKNOWN",
)
PER_CAPITA_UNITS = frozenset({"SINGLE", "MULTI_N"})
BOARD_EXCLUDED_UNITS = frozenset(
    {"VOUCHER", "FAMILY", "PER_TABLE", "PAY_AT_STORE", "UNKNOWN"}
)

_CN_NUM = {
    "一": 1, "单": 1, "二": 2, "两": 2, "双": 2, "三": 3, "四": 4, "五": 5,
    "六": 6, "七": 7, "八": 8, "九": 9, "十": 10,
}
_PERSON_RE = re.compile(
    r"(\d+|[一二两双单三四五六七八九十])\s*(?:[-~至]\s*(\d+|[一二两双单三四五六七八九十])\s*)?人"
)
_FAMILY_RE = re.compile(r"家庭|亲子|儿童|全家|一家|宝宝")
_VOUCHER_RE = re.compile(r"代金券|抵用券|券包|现金券")
_TABLE_RE = re.compile(r"按桌|整桌|一桌|桌餐|包桌")
_PAY_RE = re.compile(r"到店付|到店支付|到店结算|现付")
_LUNCH_RE = re.compile(r"午餐|午市|工作日.*午|周一至周五.*午")
_DINNER_RE = re.compile(r"晚餐|晚市|工作日.*晚|周一至周五.*晚")
_WEEKEND_RE = re.compile(r"周末|双休|节假日")
_ALLDAY_RE = re.compile(r"全天|不限时|任意时段")


def infer_unit_type_and_persons(title: str | None) -> tuple[str, int | None]:
    """从原始标题推断计价形态与人数；无法解析返回 ('UNKNOWN', None)。"""
    text = title or ""
    if _FAMILY_RE.search(text):
        return "FAMILY", None
    if _VOUCHER_RE.search(text):
        return "VOUCHER", None
    if _TABLE_RE.search(text):
        return "PER_TABLE", None
    if _PAY_RE.search(text):
        return "PAY_AT_STORE", None
    for match in _PERSON_RE.finditer(text):
        low = _to_int(match.group(1))
        high = _to_int(match.group(2)) if match.group(2) else None
        persons = high if high is not None else low
        if persons is not None and 1 <= persons <= 20:
            return ("SINGLE" if persons == 1 else "MULTI_N"), persons
    return "UNKNOWN", None


def _to_int(token: str | None) -> int | None:
    if not token:
        return None
    return int(token) if token.isdigit() else _CN_NUM.get(token)


def normalize_time_window(raw: str | None) -> str | None:
    """标准化时段标签；无法归一存原文（data-model §4.2）。"""
    if not raw or not raw.strip():
        return None
    text = raw.strip()
    if _WEEKEND_RE.search(text):
        return "weekend"
    if _ALLDAY_RE.search(text):
        return "all_day"
    if _LUNCH_RE.search(text):
        return "workday_lunch"
    if _DINNER_RE.search(text):
        return "workday_dinner"
    return text


def compute_price_columns(
    *,
    sale_price_cents: int | None,
    member_price_cents: int | None,
    extra_fee_cents: int | None,
    persons: int | None,
    unit_type: str,
) -> dict[str, int | None]:
    """三个人均字段的生成守卫；extra_fee NULL 按 0 计入 effective（SQL IFNULL）。"""
    empty = {
        "per_capita_cents": None,
        "member_per_capita_cents": None,
        "effective_per_capita_cents": None,
    }
    if unit_type not in PER_CAPITA_UNITS or persons is None or persons <= 0:
        return empty
    if sale_price_cents is None:
        return empty
    return {
        "per_capita_cents": div_to_cents(sale_price_cents, persons),
        "member_per_capita_cents": (
            div_to_cents(member_price_cents, persons)
            if member_price_cents is not None else None
        ),
        "effective_per_capita_cents": div_to_cents(
            add_cents(sale_price_cents, extra_fee_cents), persons
        ),
    }


def board_per_capita(per_capita: int | None, member_per_capita: int | None) -> tuple[int | None, str]:
    """最低价视图主榜值 = LEAST(P_MAIN, P_MEMBER)；P_COND 永不参与。"""
    if member_per_capita is not None and (
        per_capita is None or member_per_capita < per_capita
    ):
        return member_per_capita, "P_MEMBER"
    return per_capita, "P_MAIN"


def is_comparable_unit(unit_type: str) -> bool:
    return unit_type in PER_CAPITA_UNITS


def normalize_deal(
    raw: DealRaw,
    *,
    diff_threshold_cents: int = 1000,
    previous_sale_cents: int | None = None,
) -> dict[str, Any]:
    """DealRaw -> price_snapshots 可写列（不含 id/date/run_id/source_date）。"""
    unit_type = raw.unit_type
    persons = raw.persons
    if unit_type == "UNKNOWN" or persons is None:
        inferred_type, inferred_persons = infer_unit_type_and_persons(raw.title_observed)
        if unit_type == "UNKNOWN":
            unit_type = inferred_type
        if persons is None:
            persons = inferred_persons
    if unit_type not in UNIT_TYPES:
        unit_type = "UNKNOWN"
    prices = compute_price_columns(
        sale_price_cents=raw.sale_price_cents,
        member_price_cents=raw.member_price_cents,
        extra_fee_cents=raw.extra_fee_cents,
        persons=persons,
        unit_type=unit_type,
    )
    fresh = raw.sale_price_cents is not None
    reason = None
    if fresh:
        reason = derive_degraded_reason(
            extra_fee_cents=raw.extra_fee_cents,
            usable_time_window=raw.usable_time_window,
            booking_required=raw.booking_required,
            cache_suspected=cents_diff_exceeds(
                previous_sale_cents, raw.sale_price_cents, diff_threshold_cents
            ),
        )
    return {
        "sale_price_cents": raw.sale_price_cents,
        "member_price_cents": raw.member_price_cents,
        "cond_price_cents": raw.cond_price_cents,
        "cond_type": raw.cond_type,
        "cond_note": raw.cond_note,
        "unit_type": unit_type,
        "persons": persons,
        **prices,
        "extra_fee_cents": raw.extra_fee_cents,
        "usable_time_window": normalize_time_window(raw.usable_time_window),
        "booking_required": raw.booking_required,
        "degraded_reason": reason,
        "title_observed": raw.title_observed,
        "verify_mode": raw.verify_mode if raw.verify_mode in ("dual", "single") else "single",
        "trust_level": "fresh" if fresh else "missing",
        "error_code": None if fresh else (raw.error_code or "parse_empty"),
        "captured_at": raw.captured_at,
    }


def candidate_from_row(row: Mapping[str, Any]) -> dict[str, Any]:
    """把 v_daily_lowest 风格的行转成 lowest 候选（不做业务判断）。"""
    result = dict(row)
    result["board_per_capita"], result["winning_tier"] = board_per_capita(
        row.get("per_capita_cents"), row.get("member_per_capita_cents")
    )
    return result

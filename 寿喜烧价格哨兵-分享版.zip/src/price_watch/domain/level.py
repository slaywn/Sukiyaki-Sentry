"""档位判定：brand_level_map.json 加载、校验与匹配（纯函数，不猜档）。

价格**不是**入选门槛：passes_min_level 只接收 level，不接收价格参数。
这是 AC-26（L5 deal 降价到 199 仍在采集范围）的结构性保证。
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

_CONFIDENT = frozenset({"confirmed", "high"})
_MATCH_RANK = {"exact": 0, "contains": 1, "regex": 2}
_ENTRY_ID_RE = re.compile(r"^E\d{6}$")
_MAP_VERSION_RE = re.compile(r"^\d{4}\.\d{2}\.\d{2}-\d+$")


@dataclass(frozen=True)
class LevelDecision:
    level: int | None
    classification_status: str           # classified / unclassified
    level_source: str | None             # map / manual / None
    level_confidence: str | None
    candidates: tuple[int, ...]
    map_version: str | None
    entry_id: str | None = None
    ambiguous_match: bool = False


def validate_level_map(doc: Mapping[str, Any]) -> None:
    """按 docs/brand_level_map.schema.json 的内嵌约束校验；失败抛 ValueError。"""
    for key in ("schema_version", "map_version", "updated_at", "updated_by", "entries"):
        if key not in doc:
            raise ValueError(f"brand_level_map 缺字段: {key}")
    if doc["schema_version"] != 1:
        raise ValueError("仅支持 schema_version=1")
    if not isinstance(doc["map_version"], str) or not _MAP_VERSION_RE.match(doc["map_version"]):
        raise ValueError("map_version 必须为 YYYY.MM.DD-N")
    if not isinstance(doc["entries"], list):
        raise ValueError("entries 必须为数组")
    for entry in doc["entries"]:
        _validate_entry(entry)


def _validate_entry(entry: Mapping[str, Any]) -> None:
    required = (
        "entry_id", "brand", "shop", "platform", "raw_name_pattern",
        "match_type", "level", "confidence", "source", "status",
    )
    for key in required:
        if key not in entry:
            raise ValueError(f"entry {entry.get('entry_id')} 缺字段: {key}")
    if not _ENTRY_ID_RE.match(str(entry["entry_id"])):
        raise ValueError(f"entry_id 格式错误: {entry['entry_id']}")
    if entry["brand"] not in ("牛New寿喜烧", "一绪寿喜烧"):
        raise ValueError(f"brand 非法: {entry['brand']}")
    if entry["platform"] not in ("meituan", "dianping", "douyin", "any"):
        raise ValueError(f"platform 非法: {entry['platform']}")
    if entry["match_type"] not in ("exact", "contains", "regex"):
        raise ValueError(f"match_type 非法: {entry['match_type']}")
    if entry["confidence"] not in ("confirmed", "high", "medium", "low", "candidate"):
        raise ValueError(f"confidence 非法: {entry['confidence']}")
    if entry["status"] not in ("active", "retired"):
        raise ValueError(f"status 非法: {entry['status']}")
    level = entry["level"]
    if level is not None and (not isinstance(level, int) or isinstance(level, bool) or not 1 <= level <= 6):
        raise ValueError(f"level 非法: {level}")
    if level is None and not entry.get("candidates"):
        raise ValueError(f"entry {entry['entry_id']} level=null 时 candidates 必须非空")
    if entry["confidence"] == "candidate" and level is not None:
        raise ValueError(f"entry {entry['entry_id']} candidate 的 level 必须为 null")


def load_level_map(path: str | Path) -> dict[str, Any]:
    doc = json.loads(Path(path).read_text(encoding="utf-8"))
    validate_level_map(doc)
    return doc


def classify_title(
    raw_name: str,
    *,
    platform: str,
    level_map: Mapping[str, Any] | None = None,
    brand: str | None = None,
    shop_name: str | None = None,
    auto_classify: bool = False,
) -> LevelDecision:
    """按 shop 特异 > 通用、exact > contains > regex、entry_id 最小 匹配。"""
    version = str((level_map or {}).get("map_version") or "")
    if not level_map or not raw_name:
        return _unclassified(version)
    hits: list[tuple[tuple[int, int, str], Mapping[str, Any]]] = []
    for entry in level_map.get("entries", []):
        if entry.get("status") != "active":
            continue
        if brand and entry.get("brand") not in (brand, None):
            continue
        if entry.get("platform") not in (platform, "any"):
            continue
        if not _matches(str(entry.get("raw_name_pattern", "")), raw_name, str(entry["match_type"])):
            continue
        if entry.get("shop"):
            if not shop_name or entry["shop"] != shop_name:
                continue
            specificity = 1
        else:
            specificity = 0
        key = (-specificity, _MATCH_RANK[str(entry["match_type"])], str(entry["entry_id"]))
        hits.append((key, entry))
    if not hits:
        return _unclassified(version)
    hits.sort(key=lambda pair: pair[0])
    best_key, best = hits[0]
    ambiguous = any(key[:2] == best_key[:2] for key, _ in hits[1:])
    candidates = tuple(int(x) for x in (best.get("candidates") or []))
    level = best.get("level")
    confidence = str(best.get("confidence"))
    classified = level is not None and confidence in _CONFIDENT
    if auto_classify and not classified and len(candidates) == 1 and confidence == "low":
        level, classified = candidates[0], True
    return LevelDecision(
        level=level if classified else None,
        classification_status="classified" if classified else "unclassified",
        level_source="map" if classified else None,
        level_confidence=confidence if classified else None,
        candidates=() if classified else candidates,
        map_version=version if classified else None,
        entry_id=str(best["entry_id"]),
        ambiguous_match=ambiguous,
    )


def _matches(pattern: str, raw_name: str, match_type: str) -> bool:
    try:
        if match_type == "exact":
            return pattern == raw_name
        if match_type == "contains":
            return pattern in raw_name
        return re.search(pattern, raw_name) is not None
    except re.error:
        return False


def _unclassified(version: str) -> LevelDecision:
    return LevelDecision(None, "unclassified", None, None, (), None)


def passes_min_level(level: int | None, min_level: int = 4) -> bool:
    """入选只看档位。无价格参数——降价不改变入选资格（AC-26）。"""
    return level is not None and isinstance(level, int) and level >= min_level

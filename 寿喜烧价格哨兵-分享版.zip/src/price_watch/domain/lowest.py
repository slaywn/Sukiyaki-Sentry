"""全网最低价选取（纯函数）：品牌 × 档位 × 门店粒度，min_level 在 domain 过滤。

- 只取 A/B/C/manual 且 SINGLE/MULTI_N、主榜人均非空
- P_COND 永不进；排序：价格升序 → 同价 dual > single > manual
- 候选为 0 的三元组不出结论；无价格参数，降价不会掉榜（AC-26）
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from datetime import date
from typing import Any

from .level import passes_min_level
from .normalize import is_comparable_unit
from .trust import is_board_eligible, quality_rank

_GROUP_KEYS = ("brand", "level", "shop")


def select_lowest(
    candidates: Sequence[Mapping[str, Any]],
    *,
    min_level: int = 4,
) -> list[dict[str, Any]]:
    """选出每个 (brand, level, shop) 的最低价行；无候选则无结论。"""
    groups: dict[tuple[Any, ...], dict[str, Any]] = {}
    for candidate in candidates:
        if not _eligible(candidate, min_level):
            continue
        key = tuple(candidate.get(name) for name in _GROUP_KEYS)
        current = groups.get(key)
        if current is None or _better(candidate, current):
            groups[key] = dict(candidate)
    ranked = sorted(
        groups.values(),
        key=lambda row: (
            row["board_per_capita"],
            str(row.get("brand") or ""),
            int(row.get("level") or 0),
            str(row.get("shop") or ""),
        ),
    )
    return ranked


def _eligible(candidate: Mapping[str, Any], min_level: int) -> bool:
    if not passes_min_level(candidate.get("level"), min_level):
        return False
    if not is_board_eligible(str(candidate.get("grade") or "")):
        return False
    if not is_comparable_unit(str(candidate.get("unit_type") or "UNKNOWN")):
        return False
    if candidate.get("status") not in (None, "active"):
        return False
    if candidate.get("board_per_capita") is None:
        return False
    return True


def _better(new: Mapping[str, Any], old: Mapping[str, Any]) -> bool:
    """True 表示 new 更优。价格升序 → 质量升序 → deal_id 字典序（稳定收敛）。"""
    new_key = _order_key(new)
    old_key = _order_key(old)
    return new_key < old_key


def _order_key(row: Mapping[str, Any]) -> tuple[int, int, str]:
    grade = str(row.get("grade") or "")
    mode = row.get("verify_mode")
    return (
        int(row["board_per_capita"]),
        quality_rank(grade, mode),
        str(row.get("platform_deal_id") or row.get("url") or ""),
    )


def build_lowest_records(
    rows: Sequence[Mapping[str, Any]],
    *,
    min_level: int,
    record_factory: Callable[[dict[str, Any]], Any],
) -> list[Any]:
    """视图行 -> 对外 LowestRecord（工厂由 orchestrator 注入，domain 不依赖上层类型）。"""
    candidates = []
    for row in rows:
        item = dict(row)
        item["grade"] = str(item.get("grade") or "")
        candidates.append(item)
    return [record_factory(**{
        "brand": row["brand_name"], "level": row["level"],
        "shop_name": row["shop_name"], "platform": row["platform"],
        "per_capita_cents": row["board_per_capita"],
        "effective_per_capita_cents": row.get("effective_per_capita_cents")
        or row["board_per_capita"],
        "url": row["url"], "grade": row["grade"],
        "is_starred": bool(row.get("is_starred")),
    }) for row in select_lowest(candidates, min_level=min_level)]


def select_stale(
    rows: Sequence[Mapping[str, Any]], *, min_level: int
) -> list[dict[str, Any]]:
    """沿用值候选按 (brand, level, shop) 取最便宜一行（D 级不参与 A 级最低价排序）。"""
    groups: dict[tuple[Any, ...], dict[str, Any]] = {}
    for row in rows:
        if not passes_min_level(row.get("level"), min_level):
            continue
        if row.get("board_per_capita") is None:
            continue
        key = (row.get("brand_name"), row.get("level"), row.get("shop_name"))
        if key not in groups or row["board_per_capita"] < groups[key]["board_per_capita"]:
            groups[key] = dict(row)
    return sorted(groups.values(), key=lambda row: row["board_per_capita"])


def derive_stale_days(day: str, source_date: str | None) -> int | None:
    """沿用天数 = 今日 - 来源日；fresh/manual 无来源日时返回 None（不是 0）。"""
    if not source_date:
        return None
    try:
        delta = date.fromisoformat(day) - date.fromisoformat(source_date)
    except ValueError:
        return None
    return delta.days if delta.days > 0 else None


def derive_delta_cents(current: int | None, previous: int | None) -> int | None:
    """相对上一有效价格的变化（整数分）：涨为正、跌为负；首次入库为 None。"""
    if current is None or previous is None:
        return None
    return int(current) - int(previous)


def effective_per_capita(row: Mapping[str, Any]) -> int | None:
    """展示列的 actual 人均；缺失时回退 board 值（由调用方决定是否标注）。"""
    value = row.get("effective_per_capita_cents")
    if value is not None:
        return int(value)
    board = row.get("board_per_capita")
    return int(board) if board is not None else None

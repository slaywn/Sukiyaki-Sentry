"""快速模式目标三源合并（纯函数）：starred > top5 > recovery，去重后截断上限。"""

from __future__ import annotations

from collections.abc import Iterable


def merge_targets(
    *,
    starred: Iterable[int],
    top_lowest: Iterable[int],
    recovery: Iterable[int],
    limit: int,
) -> list[int]:
    """按优先级合并去重；limit <=0 返回空。"""
    if limit <= 0:
        return []
    ordered: list[int] = []
    for source in (starred, top_lowest, recovery):
        for deal_id in source:
            if deal_id not in ordered:
                ordered.append(deal_id)
    return ordered[:limit]

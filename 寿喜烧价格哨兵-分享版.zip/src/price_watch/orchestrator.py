"""编排层：抓取 -> 解析 -> 定档/归一化 -> 幂等入库 -> 覆盖物化 -> 最低价 -> 报告钩子。

对 main.py 暴露的固定签名见 SPEC §5。运维命令实现在同包 admin.py，此处统一再导出。

E29 误报：本机 CLI 无 HTTP 端点；"verify" 为领域字段而非登录路由，不适用 Web 限流。
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

from .admin import (  # 再导出：from price_watch.orchestrator import bootstrap, ...
    PLATFORMS, TIERS, bootstrap, classify, enable, login, record, report_for_date,
    star, to_target, unstar, verify,
)
from .config import (
    Config, call_report_hook, disable_platform, load_config, output_paths, platform_enabled,
)
from .domain import fast_targets, level as level_domain, lowest as lowest_domain
from .domain import normalize as normalize_domain
from .domain import trust as trust_domain
from .fetchers.base import FetchTarget, close_contexts, fetch_all_platforms
from .parsers.models import DealRaw, FetchFailure, FetchPage, utc_now_iso
from .storage import db as db_mod
from .storage.repositories import deals_repo, runs_repo, shops_repo, snapshots_repo


@dataclass
class LowestRecord:
    brand: str
    level: int
    shop_name: str
    platform: str
    per_capita_cents: int
    effective_per_capita_cents: int
    url: str
    grade: str
    is_starred: bool
    # 以下四项供即时页 A/B 分区、行内时间、沿用天数与涨红跌绿（Spec 7.1/8）
    captured_at: str | None = None              # 该 deal 快照行的抓取时刻 ISO8601，非 run 开始时刻
    delta_cents: int | None = None              # 相对上一有效价格，正=涨 负=跌
    stale_days: int | None = None               # 仅 stale 有值；fresh 必须是 None
    source_date: str | None = None              # 仅 stale：价格真实来源日


@dataclass
class RunResult:
    run_id: int
    trigger_type: str
    deals_attempted: int = 0
    deals_ok: int = 0
    fresh_count: int = 0
    stale_count: int = 0
    missing_count: int = 0
    manual_count: int = 0
    lowest_records: list[LowestRecord] = field(default_factory=list)
    output_paths: dict[str, str] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    previous_captured_at: datetime | str | None = None
    tier_pending: int = 0    # 当日 classification_status='unclassified' 的 deal 数
    unit_pending: int = 0    # 当日 unit_type='UNKNOWN' 的 deal 数
    discontinued: list[dict[str, Any]] = field(default_factory=list)


def run_daily(window: str = "am") -> RunResult:
    """定时全量：window=am -> scheduled_main，pm -> scheduled_retry。"""
    trigger = "scheduled_retry" if window == "pm" else "scheduled_main"
    config = load_config()
    conn = db_mod.initialize(config.db_path)
    if not shops_repo.has_confirmed_shops(conn):
        conn.close()
        return RunResult(0, trigger, errors=[
            "bootstrap_gate_failed: 无已确认门店，拒绝跑批（先运行 bootstrap 逐店勾选）"
        ])
    targets = [to_target(row) for row in deals_repo.list_active(conn)]
    return _execute_run(config, conn, trigger, targets, materialize_all=True)


def run_now(full: bool = False) -> RunResult:
    """手动触发：非 full 仅抓 Top5 + 标星 + 待恢复（去重后 <=15 条）。"""
    trigger = "manual_full" if full else "manual_quick"
    config = load_config()
    conn = db_mod.initialize(config.db_path)
    if not shops_repo.has_confirmed_shops(conn):
        conn.close()
        return RunResult(0, trigger, errors=["bootstrap_gate_failed: 无已确认门店，拒绝跑批"])
    targets = ([to_target(r) for r in deals_repo.list_active(conn)]
               if full else _fast_targets(conn, config))
    return _execute_run(config, conn, trigger, targets, materialize_all=full)


def _execute_run(
    config: Config, conn: Any, trigger: str, targets: list[FetchTarget], *, materialize_all: bool
) -> RunResult:
    day = date.today().isoformat()
    now = utc_now_iso()
    level_map = _load_map(config)
    grouped: dict[str, list[FetchTarget]] = defaultdict(list)
    for target in targets:
        grouped[target.platform].append(target)
    grouped = {p: items for p, items in grouped.items() if platform_enabled(config, p)}
    pages, _degraded = fetch_all_platforms(config, grouped, simulate=config.simulate_fetch)
    result = RunResult(0, trigger)
    for platform in PLATFORMS:
        page = pages.get(platform)
        if page is None:
            continue
        run_id = runs_repo.start_run(
            conn, run_date=day, platform=platform, trigger_type=trigger, started_at=now
        )
        if result.run_id == 0:
            result.run_id = run_id
        attempted = len(grouped[platform])
        result.deals_attempted += attempted
        _ingest_page(conn, page, config, level_map, run_id, day, now, result)
        _finish_platform(conn, run_id, platform, page, attempted, now, result, config, day)
    if materialize_all:
        active_ids = [int(r["id"]) for r in deals_repo.list_active(conn)]
        snapshots_repo.materialize(
            conn, active_ids, day, max_stale_days=config.stale_max_days, captured_at=now,
            run_id=None,
        )
    counts = snapshots_repo.count_by_trust(conn, day)
    result.fresh_count, result.stale_count = counts["fresh"], counts["stale"]
    result.missing_count, result.manual_count = counts["missing"], counts["manual"]
    result.previous_captured_at = snapshots_repo.previous_captured_at(conn, day, now)
    pending = snapshots_repo.query_pending_review(conn)
    result.tier_pending = sum(1 for item in pending if item.get("pending_kind") == "level_pending")
    result.unit_pending = sum(1 for item in pending if item.get("pending_kind") == "unit_type_pending")
    result.discontinued = snapshots_repo.query_discontinued(conn)
    result.lowest_records = _build_lowest(conn, day, config)
    result.output_paths = output_paths(config, day)
    call_report_hook("render_live" if trigger == "manual_quick" else "render_daily",
                     result, config=config, day=day)
    if config.simulate_fetch:
        result.errors.append("simulate_fetch=true: 本次为模拟抓取，数据不可用于决策")
    conn.close()
    close_contexts()
    return result


def _load_map(config: Config) -> dict[str, Any]:
    if not config.level_map_path.exists():
        return {"schema_version": 1, "map_version": "", "entries": []}
    try:
        return level_domain.load_level_map(config.level_map_path)
    except (ValueError, TypeError) as exc:
        raise RuntimeError(f"brand_level_map 校验失败，拒绝跑批：{exc}") from exc


def _ingest_page(
    conn: Any, page: FetchPage, config: Config, level_map: dict[str, Any],
    run_id: int, day: str, now: str, result: RunResult,
) -> None:
    for deal in page.deals:
        decision = level_domain.classify_title(
            deal.title_observed, platform=deal.platform, level_map=level_map,
            brand=deal.brand, shop_name=deal.shop_name, auto_classify=config.auto_classify,
        )
        sku_id = shops_repo.ensure_sku(
            conn, shop_id=_deal_sku(conn, deal), name=deal.title_observed, decision=decision,
        )
        deal_id = deals_repo.upsert_deal(
            conn, sku_id=sku_id, platform=deal.platform,
            platform_deal_id=deal.platform_deal_id, url=deal.url,
            title_observed=deal.title_observed, today=day,
        )
        values = normalize_domain.normalize_deal(
            deal, diff_threshold_cents=config.cache_suspected_diff_cents,
            previous_sale_cents=snapshots_repo.same_day_sale(conn, deal_id, day),
        )
        values["fetch_run_id"] = run_id
        snapshots_repo.upsert(conn, deal_id, day, values,
                              cache_diff_threshold_cents=config.cache_suspected_diff_cents)
        result.deals_ok += 1
    for failure in page.failures:
        _ingest_failure(conn, failure, run_id, day, now, result)


def _deal_sku(conn: Any, deal: DealRaw) -> int:
    """已存在的 deal 沿用映射；新 deal 必须命中已确认门店，绝不猜档入库。"""
    row = deals_repo.get_deal(conn, deal.platform, deal.platform_deal_id)
    if row is not None:
        return int(row["sku_id"])
    shop = shops_repo.find_confirmed_shop(conn, deal.brand, deal.shop_name)
    if shop is None:
        raise ValueError(f"deal {deal.platform_deal_id} 无匹配已确认门店，拒绝入库")
    return shops_repo.ensure_sku(conn, shop_id=int(shop["id"]), name=deal.title_observed)


def _ingest_failure(
    conn: Any, failure: FetchFailure, run_id: int, day: str, now: str, result: RunResult,
) -> None:
    row = deals_repo.get_deal(conn, failure.platform, failure.platform_deal_id)
    if row is None:
        result.errors.append(f"unknown_deal: {failure.platform}/{failure.platform_deal_id}")
        return
    if failure.error_code == "not_found":
        deals_repo.set_status(conn, int(row["id"]), "discontinued", day)
        return  # 停售 deal 当日不产生任何快照行（含 missing）
    snapshots_repo.upsert(conn, int(row["id"]), day, {
        "unit_type": "UNKNOWN", "verify_mode": "single", "trust_level": "missing",
        "error_code": failure.error_code, "captured_at": now, "fetch_run_id": run_id,
    })


def _finish_platform(
    conn: Any, run_id: int, platform: str, page: FetchPage, attempted: int,
    now: str, result: RunResult, config: Config, day: str,
) -> None:
    failed = len(page.failures)
    if page.captcha_hit:
        status, code = "aborted", "captcha_hit"
        result.errors.append(f"{platform}: 验证码即停，未打码未代理")
    elif failed and failed == attempted:
        status, code = "failed", "all_pages_failed"
    elif failed:
        status, code = "partial", page.failures[0].error_code
    else:
        status, code = "ok", None
    runs_repo.finish_run(
        conn, run_id, status=status, deals_attempted=attempted,
        deals_ok=attempted - failed, pages_used=page.pages_used,
        error_code=code, error_summary=f"{failed}/{attempted} failed", finished_at=now,
    )
    if runs_repo.consecutive_failed_days(conn, platform, day) >= 3:
        disable_platform(config, platform, "3 consecutive failed days")
        result.errors.append(f"{platform}: 连续 3 日失败已自动停用，需 enable 恢复")


def _fast_targets(conn: Any, config: Config) -> list[FetchTarget]:
    latest = conn.execute("SELECT MAX(snapshot_date) d FROM price_snapshots").fetchone()
    day = str(latest["d"]) if latest and latest["d"] else date.today().isoformat()
    top = snapshots_repo.query_daily_lowest(conn, day)
    top_ids = [int(r["platform_deal_id"]) for r in sorted(
        top, key=lambda r: r["board_per_capita"])[:5]]
    ids = fast_targets.merge_targets(
        starred=[int(r["id"]) for r in deals_repo.list_starred(conn)],
        top_lowest=top_ids,
        recovery=[int(r["id"]) for r in deals_repo.list_recovery(conn, day)],
        limit=config.fast_mode_max_deals,
    )
    rows = {int(r["id"]): r for r in deals_repo.list_by_ids(conn, ids)}
    return [to_target(rows[i]) for i in ids if i in rows]


def _build_lowest(conn: Any, day: str, config: Config) -> list[LowestRecord]:
    """A 区 fresh/manual 最低价 + B 区 stale 沿用值；四字段在此派生，不新增 DB 列。"""
    fresh = snapshots_repo.query_daily_lowest(conn, day)
    stale = snapshots_repo.query_stale_lowest(conn, day)
    ids = [int(r["platform_deal_id"]) for r in fresh + stale]
    prior = snapshots_repo.previous_board_prices(conn, ids, day)
    graded = []
    for row in fresh:
        item = dict(row)
        item["grade"] = trust_domain.derive_grade(
            str(item["trust_level"]), item.get("verify_mode"), item.get("degraded_reason")
        )
        graded.append(item)
    winners = lowest_domain.build_lowest_records(
        graded, min_level=config.min_level, record_factory=LowestRecord
    )
    # build_lowest_records 不携带 deal_id，主榜记录按 url 与行一一回填派生字段。
    by_url = {str(r["url"]): r for r in graded}
    for record in winners:
        _fill_derived(record, by_url.get(record.url, {}), prior, day, stale=False)
    for row in lowest_domain.select_stale(stale, min_level=config.min_level):
        record = LowestRecord(
            brand=str(row["brand_name"]), level=int(row["level"]),
            shop_name=str(row["shop_name"]), platform=str(row["platform"]),
            per_capita_cents=int(row["board_per_capita"]),
            effective_per_capita_cents=int(row.get("effective_per_capita_cents")
                                           or row["board_per_capita"]),
            url=str(row["url"]), grade="D", is_starred=bool(row.get("is_starred")),
        )
        _fill_derived(record, row, prior, day, stale=True)
        winners.append(record)
    return winners


def _fill_derived(record: LowestRecord, row: dict[str, Any], prior: dict[int, int],
                  day: str, *, stale: bool) -> None:
    """captured_at/delta_cents/stale_days/source_date 的唯一定值点。"""
    if not row:
        return
    record.captured_at = str(row["captured_at"]) if row.get("captured_at") else None
    deal_id = int(row.get("platform_deal_id") or 0)
    record.delta_cents = lowest_domain.derive_delta_cents(record.per_capita_cents, prior.get(deal_id))
    record.source_date = str(row["source_date"]) if stale and row.get("source_date") else None
    record.stale_days = lowest_domain.derive_stale_days(day, record.source_date) if stale else None


__all__ = ["RunResult", "LowestRecord", "run_daily", "run_now", "bootstrap", "verify",
           "record", "classify", "star", "unstar", "enable", "login", "report_for_date"]

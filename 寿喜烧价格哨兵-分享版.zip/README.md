# 寿喜烧价格哨兵 — 启动说明

本地 Windows 脚本：每天抓上海核心商圈「牛New / 一绪」高阶档团购价，产出 HTML + Excel 日报；双击即时抓当前价并弹系统通知。无服务器、无注册、无常驻窗口。

## 0. 环境准备（一次）

```bat
cd /d <本项目解压后的目录>
pip install -r requirements.txt
set PYTHONPATH=src
```

> `requirements.txt` 由后端维护。若 `pip` 与 `python` 指向不同解释器，请用同一个解释器安装与运行（本项目锁 Python 3.13.x）。
> 依赖装好后执行 `pip freeze > requirements-lock.txt` 回填真实版本。

## 1. 三条命令跑通（后端就绪后）

```bat
python -m price_watch bootstrap
python -m price_watch verify
python -m price_watch run-daily
```

- `bootstrap`：登录引导 + 固定上海定位 + 生成逐店勾选种子表（`config/` 下 Excel）。**必须逐店勾选确认，未确认时 run-daily 拒绝跑批，无 `--force`。**
- `verify`：试抓一轮，人工核对 10 个 deal 的价格与平台页面一致；有冲突返回非零。
- `run-daily`：全量抓取 + 物化 + 日报。退出码 `0` 全成功 / `1` 部分缺失 / `2` 全部失败。

产出：`data/reports/YYYY-MM-DD/daily.html` 与 `daily.xlsx`。

## 2. 双击即时抓取

双击项目根目录的 **`启动抓取.vbs`**：

- 无控制台窗口；文件锁保证连续双击只跑一个进程（卡死的锁 15 分钟后自动回收）。
- 立即弹 Toast「正在抓取实时价」，1-2 分钟后弹结果档 Toast 并自动打开即时结果页。
- 日志：`data/logs/run-now.log`；结果页：`data/reports/live/YYYY-MM-DD_HHMM.html`。
- 失败时 Toast + 结果页顶部**双通道**同时显示原因与下一步动作。

等价命令行：`python -m price_watch run-now`（加 `--no-open` 可不自动开浏览器，`--full` 为手动全量）。

## 3. 报告读法（两页不混用）

- **日报**：刊头 / 今日结论 / 变动榜 / 平台价差 / 待人工确认 / 可信度提示 / 明细 / 元信息。三行状态条为 fresh 率、stale 沿用数、missing 缺失数。
- **即时结果页**：**区块 A = 本次刷新（按区内价格升序，最多 5 条，不满不补）**，**区块 B = 其余沿用值（区内独立排序，最多 3 条，每行带自己的抓取时间）**，两区 1px 实线分隔，禁止跨区混排。页首横幅固定文案给出本次抓取时刻与刷新项数。
- **涨跌色**：涨红、跌绿（中国习惯），并配三角方向图标双通道。
- **可信度四态**：实时（fresh，零标记）/ 沿用（stale，琥珀实底 + 数字降权）/ 人工（manual，蓝灰）/ 缺失（missing，危险描边、不显示数字）。A/B/C/D/X 仅作 Excel 审计脚注，不上屏。
- 沿用值即使为全场最低也**不挂「全网最低」徽标**。

## 4. 其他命令

| 命令 | 作用 |
|---|---|
| `python -m price_watch login [--platform X]` | 重新扫码登录 |
| `python -m price_watch record --deal ID --price X --tier P_MAIN` | 人工录入今日价 |
| `python -m price_watch classify --deal ID --level L5` | 交互式定档，回写映射表 |
| `python -m price_watch star --deal ID` / `unstar` | 标星关注 / 取消 |
| `python -m price_watch enable --platform X` | 恢复被自动停用的平台 |
| `python -m price_watch report --date YYYY-MM-DD` | v2.0 开放；当前版本明确提示不支持（退出码 1） |

> `report --date` 属回溯便利功能，MVP 不实现：CLI 输出「当前版本暂不支持，v2.0 开放」并返回退出码 1，不会静默假装成功。`login` 已实现扫码重登流程。

## 5. 目录约定

- `src/price_watch/report/`：报告层（Jinja2 模板 + openpyxl + 内联 lucide 图标，颜色全部来自 `static/design-tokens.css`）。**`report/static/design-tokens.css` 是 `docs/design-tokens.css` 去除注释后的副本，116 条 token 声明逐条一致；改 token 时两处必须同步修改。**
- `data/reports/`：日报与即时结果页；`data/logs/`：双击运行日志。
- 所有报告为单文件自包含 HTML（CSS 内联、图标内联 SVG、离线可用），无前端状态管理、无动效、无外部请求。
